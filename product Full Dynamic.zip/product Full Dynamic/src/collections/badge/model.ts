import { modelOptions, Severity } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Badge extends BaseModel {
    // @prop({ type: String, required: true })
    // public title!: Map<string, string>;
    // @prop()
    // public textColor?: string;
    // @prop()
    // public backgroundColor?: string;
}
