export default class V_Badge { }
