/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import BadgeClass from './model';
import VBadgeClass from './view';
import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
/**
 * Create model of Badge Class.
 */
const BadgeModel = getModelForClass(BadgeClass);
const VBadge = getModelForClass(VBadgeClass);
/**
 * Badge gRPC server.
 */
export default class BadgeServer extends BaseServer {
    protected model = BadgeModel;
    protected view = VBadge;
    protected async dao(badge: any, _isDetailed: boolean, _isList: boolean, _call: any) {
        return BaseServer.objectDao(badge)
    }
    protected async appDao(badge: any, language: string, isDetailed: boolean, isList: boolean, call: any) {
        return BadgeServer.appDao(badge, language, isDetailed, isList, call);
    }
    public static async appDao(badge: any, language: string, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: badge._id.toString(),
            title: badge.title[language] ?? '',
            textColor: badge.textColor ?? '',
            backgroundColor: badge.backgroundColor ?? '',
        };
    }
}
