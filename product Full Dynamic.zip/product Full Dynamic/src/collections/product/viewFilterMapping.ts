// view for filter mapping system
export default class ViewProductFilterMapping {
    public _id!: string;
}
