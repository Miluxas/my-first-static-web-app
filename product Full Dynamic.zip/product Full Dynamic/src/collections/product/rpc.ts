/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData, status } from 'grpc';
import ProductClass from './model';
import ProductViewSkuClass from './view';
import ProductViewFilterMappingClass from './viewFilterMapping';
import SkuClass, { VariationSet } from '../sku/model';
import VariationClass from '../variation/model';
import VariationItemClass from '../variation/itemModel';
import FavoriteClass from '../favorite/model';
import { IProduct_Server } from '../../protoDef/product_grpc_pb';
import {
    ProductAndCategoryId,
    ProductAttributeItemIds,
    ProductSkuId,
    SkuGenerate,
    SGVariation,
    AppFilterList,
} from '../../protoDef/product_pb';
import { getModelForClass, DocumentType, mongoose } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Aggregate, isValidObjectId, Types } from 'mongoose';
import BaseServer from '../common/baseServer';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import BadgeServer from '../badge/rpc';
import { Filter } from '../../protoDef/common_pb';
import { isArray } from 'lodash';
import { Func } from '@typegoose/typegoose/lib/types';
import Translate from '../common/multyLang';
import { BaseObject } from '../../protoDef/common_dynamic_pb';
/**
 * Create model of Product Class.
 */
const ProductModel = getModelForClass(ProductClass);
const ProductViewSku = getModelForClass(ProductViewSkuClass);
const ProductViewFilterMapping = getModelForClass(ProductViewFilterMappingClass);

/**
 * Create model of Attribute Class.
 */
const SkuModel = getModelForClass(SkuClass);
const VariationModel = getModelForClass(VariationClass);
const VariationItemModel = getModelForClass(VariationItemClass);
const FavoriteModel = getModelForClass(FavoriteClass);

/**
 * Product gRPC server.
 */
export default class ProductServer extends BaseServer implements IProduct_Server {
    protected model = ProductModel;
    protected view = ProductViewSku;
    protected searchOn = ['name', 'description', 'attributes.name', 'attributes.value'];
    protected customizeAggregation(call: any) {
        const countryId = call.request.getBaseinfo()!.getCountryId();

        return this.view
            .aggregate()
            .lookup({
                from: 'prices',
                as: 'prices',
                let: { dSkuId: '$defaultSkuId' },
                pipeline: [
                    {
                        $match: {
                            $expr: {
                                $and: [
                                    {
                                        $eq: ['$skuId', '$$dSkuId'],
                                    },
                                    {
                                        $eq: ['$countryId', Types.ObjectId(countryId)],
                                    },
                                ],
                            },
                        },
                    },
                ],
            })
            .lookup({
                from: 'viewquantites',
                localField: 'defaultSkuId',
                foreignField: '_id.skuId',
                as: 'quantities',
            })
            .addFields({
                price: {
                    $cond: {
                        if: { $gt: [{ $size: '$prices' }, 0] },
                        then: { $first: '$prices.price' },
                        else: '$price.price',
                    },
                },
                quantity: { $first: `$quantities.quantity.${countryId}` },
            })
            .lookup({
                from: 'viewskus',
                as: 'Skus',
                let: { pId: '$_id' },
                pipeline: [
                    {
                        $match: {
                            $expr: {
                                $eq: ['$productId', '$$pId'],
                            },
                        },
                    },
                    {
                        $lookup: {
                            from: 'prices',
                            as: 'prices',
                            let: { dSkuId: '$_id' },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [
                                                {
                                                    $eq: ['$skuId', '$$dSkuId'],
                                                },
                                                {
                                                    $eq: ['$countryId', Types.ObjectId(countryId)],
                                                },
                                            ],
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    {
                        $lookup: {
                            from: 'viewquantites',
                            localField: '_id',
                            foreignField: '_id.skuId',
                            as: 'quantities',
                        },
                    },
                    {
                        $addFields: {
                            price: {
                                $cond: {
                                    if: { $gt: [{ $size: '$prices' }, 0] },
                                    then: { $first: '$prices.price' },
                                    else: '$price.price',
                                },
                            },
                            quantity: { $first: `$quantities.quantity.${countryId}` },
                        },
                    },
                ],
            });
    }

    protected async dao(product: any, _isDetailed: boolean, _isList: boolean, call: any) {
        // As Ali say
        // if (isList == true) {
        //     return await ProductServer.ModelToObject(product, call.request.getUserId());
        // }
        const result = {};
        const price =
            parseFloat((product?.price ?? 0).toString()) * (call.request.getBaseinfo()!.getCurrencyRate() ?? 1);
        let isFave = false;
        try {
            if (call.request.getUserId() && call.request.getUserId().length > 0) {
                const fave = await FavoriteModel.findOne({
                    userId: call.request.getUserId(),
                    items: product._id,
                });
                if (fave) isFave = true;
            }
        } catch (err) {}
        // test for m.ashoori
        Object.assign(result, {
            id: product._id.toString(),
            name: product.name ?? {},
            description: product.description ?? {},
            image: product.image ?? null,
            isFavorite: isFave,
            quantity: product.quantity ?? 0,

            isActive: product.isActive,
            slug: product.slug,
            price: {
                originalPrice: price.toString(),
                offPrice: price.toString(),
                title: '',
                expire_at: 0,
                currencySymbol: call.request.getBaseinfo()!.getCurrencySymbol(),
            },
            createdAt: product.createdAt?.getTime() ?? 0,
            updatedAt: product.updatedAt?.getTime() ?? 0,
        });

        Object.assign(
            result,
            product.brand
                ? {
                      brand: {
                          id: product.brand._id.toString(),
                          name: product.brand.name ?? {},
                          image: product.brand.logo ?? null,
                      },
                  }
                : {},
        );

        Object.assign(result, {
            categories: await Promise.all(
                product.categories.map(async (categ: any) => ({
                    id: categ._id.toString(),
                    name: categ.name ?? {},
                    image: categ.image ?? null,
                })),
            ),
        });

        Object.assign(result, {
            attributeItems: await Promise.all(
                product.attributeItems.map(async (attrib: any) => ({
                    id: attrib._id.toString(),
                    name: attrib.attribute?.name ?? {},
                    value: attrib.value ?? {},
                })),
            ),
        });

        return result;
    }

    protected async appDao(product: any, language: string, _isDetailed: boolean, isList: boolean, call: any) {
        if (isList == true) {
            return await ProductServer.AppModelToObject(
                product,
                language,
                call.request.getUserId(),
                call.request.getBaseinfo()!.getCurrencyRate(),
                call.request.getBaseinfo()!.getCurrencySymbol(),
            );
        }
        const result = {};
        const price = parseFloat((product?.price ?? 0).toString()) * call.request.getBaseinfo()!.getCurrencyRate();
        let isFave = false;
        try {
            if (call.request.getUserId() && call.request.getUserId().length > 0) {
                const fave = await FavoriteModel.findOne({
                    userId: call.request.getUserId(),
                    items: product._id,
                });
                if (fave) isFave = true;
            }
        } catch (e) {}
        Object.assign(result, {
            id: product._id.toString(),
            name: Translate(product.name, language),
            description: Translate(product.description, language),
            image: product.image ?? null,
            sizeGuideId: product?.sizeGuideId?.toString() ?? null,
            isFavorite: isFave,
            quantity: product.quantity ?? 0,

            price: {
                originalPrice: price.toString(),
                offPrice: price.toString(),
                title: '',
                expire_at: 0,
                currencySymbol: call.request.getBaseinfo()!.getCurrencySymbol(),
            },
        });

        if (product.brand) {
            Object.assign(result, {
                brand: {
                    id: product.brand._id.toString(),
                    name: Translate(product.brand.name, language),
                    image: product.brand.logo ?? null,
                },
            });
        }

        if (product.categories.length > 0) {
            const categ = product.categories[0];
            Object.assign(result, {
                category: {
                    id: categ._id.toString(),
                    name: Translate(categ.name, language),
                    image: categ.image ?? null,
                },
            });
        }

        if (product.attributeItems !== undefined) {
            Object.assign(result, {
                attributes: await Promise.all(
                    product.attributeItems.map(async (attrib: any) => ({
                        id: attrib._id.toString(),
                        name: Translate(attrib.attribute.name, language),
                        value: Translate(attrib.value, language),
                    })),
                ),
            });
        }

        if (product.Skus !== undefined) {
            Object.assign(result, {
                skus: await Promise.all(
                    product.Skus.map(async (sku: any) => ({
                        id: sku._id.toString(),
                        images: sku.images.map((img: any) => img.image ?? null),
                        price: {
                            originalPrice: price.toString(),
                            offPrice: price.toString(),
                            title: '',
                            expire_at: 0,
                            currencySymbol: call.request.getBaseinfo()!.getCurrencySymbol(),
                        },
                        variations: sku.VariationItems.map((vari: any) => ({
                            itemName: Translate(vari.name, language),
                            value: vari.values,
                            name: Translate(vari.Variation.name, language),
                            type: vari.Variation.type,
                            id: vari._id.toString(),
                        })),
                    })),
                ),
            });
        }

        if (true) {
            //TODO add dynamic similar product
            Object.assign(result, {
                similarProductList: [
                    await ProductServer.AppModelToObject(
                        product,
                        language,
                        call.request.getUserId(),
                        call.request.getBaseinfo()!.getCurrencyRate(),
                        call.request.getBaseinfo()!.getCurrencySymbol(),
                    ),
                    await ProductServer.AppModelToObject(
                        product,
                        language,
                        call.request.getUserId(),
                        call.request.getBaseinfo()!.getCurrencyRate(),
                        call.request.getBaseinfo()!.getCurrencySymbol(),
                    ),
                    await ProductServer.AppModelToObject(
                        product,
                        language,
                        call.request.getUserId(),
                        call.request.getBaseinfo()!.getCurrencyRate(),
                        call.request.getBaseinfo()!.getCurrencySymbol(),
                    ),
                ],
            });
        }
        return result;
    }

    protected async afterAdd(newDoc: any) {
        const newSku = new SkuModel();
        newSku.productId = newDoc;
        newSku.variations = [];
        newSku.isActive = true;
        newSku.sku = await newSku.getDefaultSku();
        await newSku.save();
        newDoc.defaultSkuId = newSku.id;
        await newDoc.save();
        return;
    }

    public async addToCategory(
        call: ServerUnaryCall<ProductAndCategoryId>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            if (!Types.ObjectId.isValid(call.request.getCategoryId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            //  Check is product exist in category.
            const foundProduct = await ProductModel.findOne({
                _id: call.request.getId(),
                categories: call.request.getCategoryId(),
            });
            if (foundProduct === null) {
                //  Push category Id to prosuct's categoriesId array.
                ProductModel.findByIdAndUpdate(
                    { _id: call.request.getId() },
                    { $push: { categoriesId: Types.ObjectId(call.request.getCategoryId()) } },
                )
                    .then(() => {
                        callback(null, new Empty());
                        return;
                    })
                    .catch((err) => {
                        callback({ code: status.UNKNOWN, message: err.message, name: 'Save ERROR' }, null);
                        return;
                    });
            } else callback(null, new Empty());
        } catch (err) {
            console.error('!!! add to category product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public async deleteFromCategory(
        call: ServerUnaryCall<ProductAndCategoryId>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            if (!Types.ObjectId.isValid(call.request.getCategoryId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            //  Find product and pull the category's Id from categorisId array.
            ProductModel.findOneAndUpdate(
                { _id: call.request.getId() },
                { $pull: { categoriesId: Types.ObjectId(call.request.getCategoryId()) } },
            )
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err.message, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (err) {
            console.error('!!! delete from category product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public async edit(call: ServerUnaryCall<BaseObject>, callback: sendUnaryData<Struct>): Promise<void> {
        try {
            const productObj = call.request.getObject()!.toJavaScript();
            if (!Types.ObjectId.isValid(productObj._id?.toString() ?? '')) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const prod = await ProductModel.findById(productObj._id?.toString() ?? '');
            if (!prod) {
                callback({ code: 404, message: 'Product Not found.', name: 'NOT found' }, null);
                return;
            }

            //  Check is brand Id set as a API parameter.
            if (!ProductServer.productHasSku(productObj._id?.toString() ?? '')) {
                super.edit(call, callback);
            }
        } catch (err) {
            console.error('!!! edit product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public async addAttribute(
        call: ServerUnaryCall<ProductAttributeItemIds>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const mainProd = await ProductModel.findOne({
                _id: call.request.getId(),
            });
            if (!mainProd) {
                callback({ code: 404, message: 'Product Not found.', name: 'NOT found' }, null);
                return;
            }

            await Promise.all(
                call.request.getAttributeItemIdList().map(async (atl) => {
                    mainProd.attributeItemsId?.push(Types.ObjectId(atl));
                }),
            );

            mainProd.markModified('attributeItemsId');

            mainProd
                .save()
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err.message, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (err) {
            console.error('!!! add attribute product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public async deleteAttribute(
        call: ServerUnaryCall<ProductAttributeItemIds>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }

            ProductModel.findByIdAndUpdate(call.request.getId(), {
                $pull: { attributeItemsId: Types.ObjectId(call.request.getAttributeItemIdList()[0]) },
            })
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err.message, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (err) {
            console.error('!!! delete attribute product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public async setDefaultSku(call: ServerUnaryCall<ProductSkuId>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const sku = await SkuModel.findById(call.request.getSkuId());
            ProductModel.findByIdAndUpdate(call.request.getId(), {
                defaultSkuId: mongoose.Types.ObjectId(call.request.getSkuId()),
                isDiscountable: sku?.isDiscountable,
            })
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err.message, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (err) {
            console.error('!!! set default sku product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    private async autoVariGenHelper(
        skus: DocumentType<SkuClass>[],
        variationId: string,
        items: SGVariation.ItemId[],
    ): Promise<DocumentType<SkuClass>[]> {
        const result = new Array<DocumentType<SkuClass>>();
        await Promise.all(
            skus.map(async (inSku) => {
                await Promise.all(
                    items
                        .sort((a, b) => {
                            if (a.getIsDefault() && !b.getIsDefault()) return -1;
                            else if (!a.getIsDefault() && b.getIsDefault()) return 1;
                            return 0;
                        })
                        .map(async (item, index) => {
                            const varItem = await VariationItemModel.findOne({
                                _id: item.getVariationItemId(),
                                variationId: variationId,
                            });
                            if (!varItem) {
                                throw new Error('Item DONT belong to variation');
                            }
                            const newSku = new SkuModel(inSku.toObject());
                            // newSku._id = Types.ObjectId();
                            newSku.productId = inSku.productId;
                            if (!inSku.variations) newSku.variations = [];
                            newSku.variations?.push(<VariationSet>{
                                variationId: mongoose.Types.ObjectId(variationId),
                                itemId: mongoose.Types.ObjectId(item.getVariationItemId()),
                            });
                            result[index] = newSku;
                        }),
                );
            }),
        );

        return result;
    }

    public async generateSku(call: ServerUnaryCall<SkuGenerate>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getProductId())) {
                callback({ code: 400, message: 'Wrong Product ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const mainProd = await ProductModel.findOne({
                _id: call.request.getProductId(),
            });
            if (!mainProd) {
                callback({ code: 404, message: 'Product Not found.', name: 'NOT found' }, null);
                return;
            }

            let result = new Array<DocumentType<SkuClass>>();
            const newSku = new SkuModel();
            newSku.productId = Types.ObjectId(call.request.getProductId());
            newSku.variations = [];
            newSku.isActive = true;
            result.push(newSku);
            for (let i = 0; i < call.request.getVariationsList().length; i++) {
                const variationId = call.request.getVariationsList()[i].getVariationId();
                if (!Types.ObjectId.isValid(variationId)) {
                    callback(
                        {
                            code: 400,
                            message: 'Wrong Variation ID structure. ' + variationId,
                            name: 'WRONG Id',
                        },
                        null,
                    );
                    return;
                }
                const fVariation = await VariationModel.findById(variationId);
                if (!fVariation) {
                    callback({ code: 404, message: 'Variation Not found.', name: 'NOT found' }, null);
                    return;
                }

                try {
                    result = await this.autoVariGenHelper(
                        result,
                        variationId,
                        call.request.getVariationsList()[i].getVariationItemIdList(),
                    );
                } catch (err) {
                    callback({ code: 400, message: 'Item DONT belong to variation', name: 'NOT found' }, null);
                    return;
                }
            }
            const skuList = await SkuModel.find({ productId: newSku.productId });
            if (skuList && skuList.length > 0) {
                await Promise.all(
                    result.map(async (gSku) => {
                        const tmpArray = await Promise.all(
                            skuList.map((sSku) => SkuClass.RegenerateSku(sSku, gSku.variations ?? [])),
                        );
                        if (tmpArray.every((res) => res == 0)) {
                            gSku._id = new Types.ObjectId();
                            gSku.sku = await gSku.getDefaultSku();
                            await gSku.save();
                        }
                    }),
                );
            } else {
                for (let j = 0; j < result.length; j++) {
                    const sku = result[j];
                    sku.sku = await sku.getDefaultSku();
                    await sku.save();
                }
            }
            mainProd.variations = [];
            await Promise.all(
                call.request.getVariationsList().map((sGVari: SGVariation) => {
                    mainProd.variations?.push({
                        variationId: mongoose.Types.ObjectId(sGVari.getVariationId()),
                        itemsId: sGVari
                            .getVariationItemIdList()
                            .map((itemId) => mongoose.Types.ObjectId(itemId.getVariationItemId())),
                    });
                }),
            );
            mainProd.markModified('variations');
            await mainProd.save();
            callback(null, new Empty());
            return;
        } catch (err) {
            console.error('!!! product in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public static async productHasSku(productId: string): Promise<boolean> {
        return (await SkuModel.find({ productId: productId }).count()) > 0;
    }

    protected customizeAggregationFilterMapping(call: any) {
        const countryId = call.request.getBaseinfo()!.getCountryId();
        return ProductViewFilterMapping.aggregate()
            .lookup({
                from: 'prices',
                as: 'prices',
                let: { dSkuId: '$defaultSkuId' },
                pipeline: [
                    {
                        $match: {
                            $expr: {
                                $and: [
                                    {
                                        $eq: ['$skuId', '$$dSkuId'],
                                    },
                                    {
                                        $eq: ['$countryId', Types.ObjectId(countryId)],
                                    },
                                ],
                            },
                        },
                    },
                ],
            })
            .lookup({
                from: 'viewquantites',
                localField: '_id',
                foreignField: '_id.skuId',
                as: 'quantities',
            })
            .addFields({
                price: {
                    $cond: {
                        if: { $gt: [{ $size: '$prices' }, 0] },
                        then: { $first: '$prices.price' },
                        else: '$price.price',
                    },
                },
                quantity: { $first: `$quantities.quantity.${countryId}` },
            })
            .lookup({
                from: 'skus',
                as: 'Skus',
                let: { pId: '$_id' },
                pipeline: [
                    {
                        $match: {
                            $expr: {
                                $eq: ['$productId', '$$pId'],
                            },
                        },
                    },
                    {
                        $lookup: {
                            from: 'prices',
                            as: 'prices',
                            let: { dSkuId: '$_id' },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [
                                                {
                                                    $eq: ['$skuId', '$$dSkuId'],
                                                },
                                                {
                                                    $eq: ['$countryId', Types.ObjectId(countryId)],
                                                },
                                            ],
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    {
                        $lookup: {
                            from: 'viewquantites',
                            localField: '_id',
                            foreignField: '_id.skuId',
                            as: 'quantities',
                        },
                    },
                    {
                        $addFields: {
                            price: {
                                $cond: {
                                    if: { $gt: [{ $size: '$prices' }, 0] },
                                    then: { $first: '$prices.price' },
                                    else: '$price.price',
                                },
                            },
                            quantity: { $first: `$quantities.quantity.${countryId}` },
                        },
                    },
                ],
            });
    }

    public appFilter(call: ServerUnaryCall<Filter>, callback: sendUnaryData<AppFilterList>): void {
        try {
            ProductServer.CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                this.customizeAggregationFilterMapping(call),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ProductServer.ToAppFilterList(
                        list,
                        async (item) =>
                            Struct.fromJavaScript(
                                await this.appDao(item, call.request.getBaseinfo()!.getLanguage(), false, true, call),
                            ),
                        call.request.getFilter()?.toJavaScript().pagination,
                    ),
                );
            });
        } catch (err) {
            console.error('!!! appList ' + this.model.modelName + ' in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    /* eslint-disable @typescript-eslint/no-explicit-any */
    public static CommonFilterConvert(
        filterObject: any,
        aggregate: Aggregate<any[]>,
        multiLanguageFields: string[] = [],
        language: string,
    ) {
        filterObject = ProductServer.StdFilterObject(filterObject);
        aggregate.addFields({
            age: { $floor: { $divide: [{ $subtract: ['$$NOW', '$createdAt'] }, 24 * 60 * 60 * 1000] } },
        });
        let tmpObj = {};
        if (filterObject.filter) {
            tmpObj = filterObject.filter;
        }
        if (multiLanguageFields.length > 0 && language && filterObject.search) {
            const conditions: { [x: string]: { $regex: string; $options: string } }[] = [];
            multiLanguageFields.map((field) => {
                conditions.push({
                    [field + '.' + language]: { $regex: filterObject.search?.toString() ?? '', $options: 'i' },
                });
            });
            Object.assign(tmpObj, { $or: conditions });
        }
        if (filterObject.sort) {
            aggregate.sort(filterObject.sort);
        } else {
            aggregate.sort({ createdAt: -1 });
        }

        return aggregate
            .match(tmpObj)
            .facet({
                paginatedResults: [
                    { $skip: (filterObject.pagination?.page ?? 0) * (filterObject.pagination?.limit ?? 1000) },
                    { $limit: filterObject.pagination?.limit ?? 1000 },
                ],
                totalCount: [
                    {
                        $count: 'count',
                    },
                ],
                filterMapping: [
                    {
                        $group: {
                            _id: {},
                            filterMappingsList: { $push: '$filterMappings' },
                            filterMappingItemsList: { $push: '$filterMappingItems' },
                        },
                    },
                    {
                        $addFields: {
                            uniqeFilterMappings: {
                                $reduce: {
                                    input: '$filterMappingsList',
                                    initialValue: { $arrayElemAt: ['$filterMappingsList', 0] },
                                    in: { $setIntersection: ['$$this', '$$value'] },
                                },
                            },
                            allFilterMappingItems: {
                                $setIntersection: {
                                    $reduce: {
                                        input: '$filterMappingItemsList',
                                        initialValue: { $arrayElemAt: ['$filterMappingItemsList', 0] },
                                        in: { $concatArrays: ['$$this', '$$value'] },
                                    },
                                },
                            },
                        },
                    },
                ],
            })
            .project({
                paginatedResults: 1,
                totalCount: 1,
                filterMapping: 1,
            });
    }

    public static StdFilterObject(filter: any) {
        const regex = RegExp(/^[a-z|A-Z|0-9]+\s?At{1}$/);
        const keys = Object.keys(filter ?? {});
        keys.map((k: any) => {
            if (regex.test(k)) {
                filter[k] = ProductServer.StdDateValue(filter[k]);
            }
            if (isArray(filter[k])) {
                for (let index = 0; index < filter[k].length; index++) {
                    if (isValidObjectId(filter[k][index]) && typeof filter[k][index] === 'string') {
                        filter[k][index] = Types.ObjectId(filter[k][index]);
                    } else filter[k][index] = ProductServer.StdFilterObject(filter[k][index]);
                }
            } else if (typeof filter[k] === 'object') {
                filter[k] = ProductServer.StdFilterObject(filter[k]);
            } else if (isValidObjectId(filter[k]) && typeof filter[k] === 'string') {
                filter[k] = Types.ObjectId(filter[k]);
            }
        });
        return filter;
    }

    public static StdDateValue(filter: any) {
        const keys = Object.keys(filter ?? {});
        keys.map((k: any) => {
            if (isArray(filter[k])) {
                for (let index = 0; index < filter[k].length; index++) {
                    if (new Date(filter[k][index]).getTime() > 0) {
                        filter[k][index] = new Date(filter[k][index]);
                    } else filter[k][index] = ProductServer.StdDateValue(filter[k][index]);
                }
            } else if (typeof filter[k] === 'object') {
                filter[k] = ProductServer.StdDateValue(filter[k]);
            } else if (new Date(filter[k]).getTime() > 0) {
                filter[k] = new Date(filter[k]);
            }
        });
        return filter;
    }

    public static async ToAppFilterList(result: any, convertor: Func, pagination: any) {
        const tmpList = new AppFilterList();
        await Promise.all(
            result[0].paginatedResults.map(async (item: any, index: any) => {
                if (item) {
                    tmpList.getItemsList()[index] = await convertor(item);
                }
            }),
        );
        const filterList: any[] = [];
        await Promise.all(
            (result[0]?.filterMapping[0]?.uniqeFilterMappings ?? []).map((filMap: any) => {
                const objFilMap = { id: filMap._id.toHexString(), title: filMap.title ?? null, items: [] };
                filterList.push(objFilMap);
            }),
        );
        await Promise.all(
            (result[0]?.filterMapping[0]?.allFilterMappingItems ?? []).map((filMapItem: any) => {
                const objFilMapItem = { id: filMapItem._id.toHexString(), title: filMapItem.title ?? null };
                const foundFilMap = filterList.find(
                    (filMa: any) => filMa.id == filMapItem.filterMappingId.toHexString(),
                );
                if (foundFilMap) foundFilMap.items.push(objFilMapItem);
            }),
        );
        tmpList.setFilterOptionsList(filterList.map(Struct.fromJavaScript));
        const hasNext =
            (result[0]?.totalCount[0]?.count ?? 0) > ((pagination?.page ?? 0) + 1) * (pagination?.limit ?? 1000);
        tmpList.setHasnext(hasNext);
        return tmpList;
    }

    public static async AppModelToObject(
        product: any,
        lang: string,
        userId: string | undefined,
        currencyRate: number,
        currencySymbol: string,
    ) {
        const price = parseFloat((product?.price ?? 0).toString()) * currencyRate;
        const priceObject = {
            originalPrice: price.toString(),
            offPrice: price.toString(),
            title: '',
            expire_at: 0,
            currencySymbol,
        };
        // if (product.isDiscountable) {
        //     priceObject = {
        //         originalPrice: price.toString(),
        //         offPrice: (price * 0.95).toString(),
        //         title: 'Special Sell',
        //         expire_at: 0,
        //     };
        // }
        let isFave = false;
        if (userId && userId.length > 0) {
            const fave = await FavoriteModel.findOne({
                userId: userId,
                items: product._id,
            });
            if (fave) isFave = true;
        }
        return {
            id: product._id.toString(),
            name: Translate(product.name, lang),
            image: product.image ?? null,
            price: priceObject,
            isFavorite: isFave,
            quantity: product.quantity ?? 0,

            badges: await Promise.all(
                product.badges.map(async (b: any) => await BadgeServer.appDao(b, lang, false, false, null)),
            ),
            category:
                product.categories && product.categories.length > 0
                    ? {
                          id: product.categories[0]._id.toString(),
                          name: Translate(product.categories[0].name, lang),
                          image: product.categories[0].image ?? null,
                      }
                    : null,
        };
    }

    public static async ModelToObject(
        product: any,
        userId: string | undefined,
        currencyRate: number,
        currencySymbol: string,
    ) {
        const price = parseFloat((product?.price ?? 0).toString()) * currencyRate;
        const priceObject = {
            originalPrice: price.toString(),
            offPrice: price.toString(),
            title: '',
            expire_at: 0,
            currencySymbol,
        };
        // if (product.isDiscountable) {
        //     priceObject = {
        //         originalPrice: price.toString(),
        //         offPrice: (price * 0.95).toString(),
        //         title: 'Special Sell',
        //         expire_at: 0,
        //     };
        // }
        let isFave = false;
        if (userId && userId.length > 0) {
            const fave = await FavoriteModel.findOne({
                userId: userId,
                items: product._id,
            });
            if (fave) isFave = true;
        }
        return {
            id: product._id.toString(),
            name: product.name ?? {},
            image: product.image ?? null,
            price: priceObject,
            isFavorite: isFave,
            quantity: product.quantity ?? 0,

            slug: product.slug,
            category:
                product.categories && product.categories.length > 0
                    ? {
                          id: product.categories[0]._id.toString(),
                          name: product.categories[0].name ?? {},
                          image: product.categories[0].image ?? null,
                      }
                    : {},
            createdAt: product.createdAt?.getTime() ?? 0,
            updatedAt: product.updatedAt?.getTime() ?? 0,
        };
    }
}
