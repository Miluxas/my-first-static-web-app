export default class ViewProductSku {
    public _id!: string;
}
