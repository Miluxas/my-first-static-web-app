import { prop, Ref, mongoose, modelOptions, Severity } from '@typegoose/typegoose';
import Category from '../category/model';
import Brand from '../brand/model';
import BaseModel from '../common/baseModel';
import AttributeItem from '../attribute/itemModel';
import Tag from '../tag/model';
import Badge from '../badge/model';
import SizeGuide from '../sizeGuide/model';

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Product extends BaseModel {
    @prop({ type: String, required: true })
    public name!: Map<string, string>;

    @prop({ type: String })
    public slug?: string;

    @prop({ ref: Brand })
    public brandId?: Ref<Brand>;

    @prop({ ref: Category })
    public categoriesId?: Ref<Category>[];

    @prop({ ref: AttributeItem })
    public attributeItemsId?: Ref<AttributeItem>[];

    @prop({ type: mongoose.Schema.Types.Mixed })
    public variations?: { variationId?: mongoose.Types.ObjectId; itemsId?: mongoose.Types.ObjectId[] }[];

    @prop({ ref: mongoose.Types.ObjectId })
    public defaultSkuId?: Ref<mongoose.Types.ObjectId>;

    @prop({ default: true })
    public isDiscountable?: boolean;

    @prop({ ref: Tag })
    public tagsId?: Ref<Tag>[];

    @prop({ ref: Badge })
    public badgesId?: Ref<Badge>[];

    @prop({ ref: SizeGuide })
    public sizeGuideId?: Ref<SizeGuide>;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push(
            'name',
            'slug',
            'brandId',
            'categoriesId',
            'attributeItemsId',
            'variations',
            'defaultSkuId',
            'isDiscountable',
            'tagsId',
            'badgesId',
            'sizeGuideId',
        );
        return base;
    }
}
