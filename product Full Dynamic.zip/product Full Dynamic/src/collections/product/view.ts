export default class ViewProduct {
    public _id!: string;
}
