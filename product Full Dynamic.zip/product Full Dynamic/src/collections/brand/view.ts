export default class ViewBrand {}
