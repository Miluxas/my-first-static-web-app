import { prop, index, mongoose, modelOptions, Severity } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';
import BaseModel from '../common/baseModel';

@index({ name: 'text' })
@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Brand extends BaseModel {
    @prop({ type: String, required: true, unique: true })
    public name!: Map<string, string>;

    @prop({ type: mongoose.Schema.Types.Mixed })
    public logo?: Record<string, JavaScriptValue>;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('name', 'logo');
        return base;
    }
}
