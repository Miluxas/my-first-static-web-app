/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import BrandClass from './model';
import BrandViewClass from './view';
import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import Translate from '../common/multyLang';

const BrandModel = getModelForClass(BrandClass);
const BrandView = getModelForClass(BrandViewClass);
/**
 * Brand gRPC server.
 */
export default class BrandServer extends BaseServer {
    protected model = BrandModel;
    protected view = BrandView;
    protected searchOn = ['name'];
    protected async dao(item: any, _isDetailed: boolean, _isList: boolean) {
        return BaseServer.objectDao(item);
    }

    protected async appDao(item: any, language: string, isDetailed: boolean, isList: boolean) {
        return BrandServer.appDao(item, language, isDetailed, isList);
    }

    public static async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean) {
        return {
            id: item._id.toString(),
            name: Translate(item.name, language),
            logo: item.logo ?? null,
        };
    }
}
