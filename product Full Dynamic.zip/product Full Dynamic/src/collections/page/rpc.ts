/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData } from 'grpc';
import PageClass from './model';
import PageViewClass from './view';
import { IPage_Server } from '../../protoDef/page_grpc_pb';
import { BoxOrder, ByName } from '../../protoDef/page_pb';
import { getModelForClass } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Types } from 'mongoose';
import BoxServer from '../box/rpc';
import BaseServer from '../common/baseServer';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import Translate from '../common/multyLang';
/**
 * Create model of Page Class.
 */
const PageModel = getModelForClass(PageClass);
const PageView = getModelForClass(PageViewClass);
/**
 * Page gRPC server.
 */
export default class PageServer extends BaseServer implements IPage_Server {
    protected model = PageModel;
    protected view = PageView;
    protected async dao(page: any, isDetailed: boolean, _isList: boolean, call: any) {
        return {
            id: page._id.toString(),
            title: page.title ?? {},
            storeId: page.storeId?.toHexString() ?? '',
            Boxes: isDetailed
                ? await Promise.all((page.Boxes ?? []).map(async (ar: any) => await BoxServer.dao(ar, call)))
                : [],
            createdAt: page.createdAt?.getTime() ?? 0,
            updatedAt: page.updatedAt?.getTime() ?? 0,
        };
    }
    protected async appDao(page: any, language: string, isDetailed: boolean, _isList: boolean, call: any) {
        const boxes: any[] = [];
        if (isDetailed) {
            await Promise.all(
                (page.Boxes ?? []).map(async (ar: any) => {
                    const ind = page.boxes.findIndex((bi: any) => bi.boxId == ar._id.toString());
                    boxes[ind] = await BoxServer.appDao(ar, language, call);
                }),
            );
        }
        return {
            id: page._id.toString(),
            title: Translate(page.name, language),
            createdBy: page.createdBy?.toHexString() ?? '',
            storeId: page.storeId?.toHexString() ?? '',
            Boxes: boxes,
        };
    }
    public getByName(call: ServerUnaryCall<ByName>, callback: sendUnaryData<Struct>): void {
        try {
            PageView.aggregate([
                {
                    $match: {
                        isDeleted: false,
                        name: call.request.getName(),
                        storeId: Types.ObjectId(call.request.getBaseinfo()!.getStoreId()),
                    },
                },
            ]).then(async (list: any) => {
                if (list.length == 0) {
                    callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                    return;
                }
                callback(null, Struct.fromJavaScript(await this.dao(list[0], true, false, call)));
            });
        } catch (error) {
            console.error('!!! get ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
    public appGetByName(call: ServerUnaryCall<ByName>, callback: sendUnaryData<Struct>): void {
        try {
            PageView.aggregate([
                {
                    $match: {
                        isDeleted: false,
                        name: call.request.getName(),
                        //storeId: Types.ObjectId(call.request.getBaseinfo()!.getStoreId()),
                    },
                },
            ]).then(async (list: any) => {
                if (list.length == 0) {
                    callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                    return;
                }
                callback(
                    null,
                    Struct.fromJavaScript(
                        await this.appDao(list[0], call.request.getBaseinfo()!.getLanguage(), true, false, call),
                    ),
                );
            });
        } catch (error) {
            console.error('!!! get ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async setBoxOrder(call: ServerUnaryCall<BoxOrder>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const page = await PageModel.findById(call.request.getId());
            if (page) {
                const fBox = page.boxes?.find((sId) => sId.boxId == Types.ObjectId(call.request.getBoxId()));
                if (fBox) {
                    page.boxes = page.boxes?.filter((sId) => sId.boxId != Types.ObjectId(call.request.getBoxId()));
                    page.boxes?.splice(call.request.getOrder(), 0, fBox);
                    page.markModified('boxes');
                }
                page.save().then(() => {
                    callback(null, new Empty());
                });
            }
        } catch (error) {
            console.error('!!! set page box order in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
/**
 *
featured([Collection]),
product([Product]),
collection(Collections),
collection_list([Collections]),
category([Category])
 */
