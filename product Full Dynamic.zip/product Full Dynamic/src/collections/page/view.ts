export default class ViewPage {}
