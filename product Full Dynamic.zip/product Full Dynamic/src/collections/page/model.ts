import { prop, Ref, modelOptions, Severity } from '@typegoose/typegoose';
import Box from '../box/model';
import BaseModel from '../common/baseModel';
class PageBox {
    @prop({ ref: Box })
    public boxId?: Ref<Box>;
    @prop({ default: true })
    public isActive?: boolean;
}
@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Page extends BaseModel {
    @prop({ type: PageBox })
    public boxes?: PageBox[];

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('boxes');
        return base;
    }
}
