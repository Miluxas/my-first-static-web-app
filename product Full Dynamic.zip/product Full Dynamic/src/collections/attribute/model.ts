import { prop } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';

export default class Attribute extends BaseModel {
    @prop({ type: String, required: true })
    public name!: Map<string, string>;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('name');
        return base;
    }
}
