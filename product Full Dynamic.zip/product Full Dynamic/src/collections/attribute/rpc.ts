/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import AttributeClass from './model';
import AttributeViewClass from './view';
import UnmappedAttributeViewClass from './unmappedView';
import AttributeItemClass from './itemModel';
import { IAttribute_Server } from '../../protoDef/attribute_grpc_pb';

import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import { sendUnaryData, ServerUnaryCall, status } from 'grpc';
import { AttributeItem } from '../../protoDef/attribute_pb';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import { Types } from 'mongoose';
import { Filter, Id, List } from '../../protoDef/common_pb';
import CommonFilterConvert from '../common/filterConvert';
import ToPanelList from '../common/panelListDecorator';
/**
 * Create model of Attribute Class.
 */
const AttributeModel = getModelForClass(AttributeClass);
const AttributeView = getModelForClass(AttributeViewClass);
const AttributeItemModel = getModelForClass(AttributeItemClass);
const UnmappedAttributeView = getModelForClass(UnmappedAttributeViewClass);

/**
 * Attribute gRPC server.
 */
export default class AttributeServer extends BaseServer implements IAttribute_Server {
    protected model = AttributeModel;
    protected view = AttributeView;
    protected async dao(attrib: any, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: attrib._id.toString(),
            name: attrib.name ?? null,
            items: attrib.items.map((item: any) => ({ id: item._id.toString(), value: item.value ?? null })),
        };
    }

    protected async appDao(attrib: any, language: string, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: attrib._id.toString(),
            name: attrib.name[language] ?? '',
            items: attrib.items.map((item: any) => ({ id: item._id.toString(), value: item.value[language] ?? '' })),
        };
    }

    public unmappedItems(call: ServerUnaryCall<Filter>, callback: sendUnaryData<List>): void {
        try {
            CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                UnmappedAttributeView.aggregate([{ $match: { isDeleted: false } }]),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ToPanelList(list, async (item) =>
                        Struct.fromJavaScript({
                            id: item._id.toString(),
                            name: item.name ?? {},
                            value: item.value ?? {},
                        }),
                    ),
                );
            });
        } catch (error) {
            console.error('!!! list ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async addItem(call: ServerUnaryCall<AttributeItem>, callback: sendUnaryData<Struct>): Promise<void> {
        try {
            const newAttribItem = new AttributeItemModel();
            newAttribItem.value = JSON.parse(call.request.getValue());
            newAttribItem.attributeId = Types.ObjectId(call.request.getId());
            newAttribItem.save().then(async () => {
                callback(null, await this.getById(call.request.getId(), call));
                return;
            });
        } catch (error) {
            console.error('!!! add Attribute in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public editItem(call: ServerUnaryCall<AttributeItem>, callback: sendUnaryData<Struct>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Attribute ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            AttributeItemModel.findById(call.request.getId()).then(async (attributeItem) => {
                if (!attributeItem) {
                    callback({ code: 404, message: 'Attribute Not found.', name: 'NOT found' }, null);
                    return;
                }
                //  Check is logo set as a API parameter.
                if (call.request.getValue().length > 0)
                    try {
                        attributeItem.value = JSON.parse(call.request.getValue());
                        attributeItem.markModified('name');
                    } catch (error) {
                        console.error('!!! updateAttribute in Server => ', error);
                        callback({ code: 400, message: 'Name is NOT a Json string', name: 'JSON ERROR' }, null);
                    }

                attributeItem.updatedAt = new Date();

                attributeItem
                    .save()
                    .then(async () => {
                        callback(null, await this.getById(attributeItem.id, call));
                        return;
                    })
                    .catch((err) => {
                        console.error('!!! updateAttribute in Server => ', err);
                        callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                        return;
                    });
            });
        } catch (error) {
            console.error('!!! edit Attribute in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public deleteItem(call: ServerUnaryCall<Id>, callback: sendUnaryData<Struct>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    {
                        code: 400,
                        message: 'Wrong ' + AttributeItemModel.modelName + ' ID structure.',
                        name: 'WRONG Id',
                    },
                    null,
                );
                return;
            }
            AttributeItemModel.findByIdAndUpdate(call.request.getId(), { isDeleted: true }).then(async (item: any) => {
                if (!item) {
                    callback(
                        { code: 404, message: '' + AttributeItemModel.modelName + ' Not found.', name: 'NOT found' },
                        null,
                    );
                    return;
                }
                callback(null, new Struct());
            });
        } catch (error) {
            console.error('!!! delete ' + AttributeItemModel.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
