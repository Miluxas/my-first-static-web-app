import { prop, Ref } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';
import Attribute from './model';

export default class AttributeItem extends BaseModel {
    @prop({ ref: Attribute, required: true })
    public attributeId!: Ref<Attribute>;

    @prop({ type: String, required: true })
    public value!: Map<string, string>;
}
