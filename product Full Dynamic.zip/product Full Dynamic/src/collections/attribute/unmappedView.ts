export default class UnmappedAttribute {
    public _id!: string;
}
