export default class ViewAttribute {
    public _id!: string;
}
