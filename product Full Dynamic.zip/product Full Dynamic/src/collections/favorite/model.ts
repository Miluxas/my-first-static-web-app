import { prop, mongoose } from '@typegoose/typegoose';
export default class Favorite {
    public _id!: mongoose.Types.ObjectId;

    @prop({ type: mongoose.Types.ObjectId })
    public userId?: mongoose.Types.ObjectId;

    @prop({ ref: mongoose.Types.ObjectId })
    public items?: mongoose.Types.ObjectId[];

    @prop({ default: new Date() })
    public createdAt?: Date;

    @prop({ default: new Date() })
    public updatedAt?: Date;
}
