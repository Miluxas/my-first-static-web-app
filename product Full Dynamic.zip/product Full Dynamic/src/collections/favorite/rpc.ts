/* eslint-disable @typescript-eslint/no-array-constructor */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData } from 'grpc';
import FavoriteClass from './model';
import { IFavorite_Server } from '../../protoDef/favorite_grpc_pb';
import { OwnerId } from '../../protoDef/favorite_pb';
import { getModelForClass, mongoose } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { AppList, Filter } from '../../protoDef/common_pb';
import CommonFilterConvert from '../common/filterConvert';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import { Types } from 'mongoose';
/**
 * Create model of Favorite Class.
 */
const FavoriteModel = getModelForClass(FavoriteClass);
/**
 * Favorite gRPC server.
 */
export default class FavoriteServer implements IFavorite_Server {
    public async add(call: ServerUnaryCall<OwnerId>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            const favorite = await FavoriteModel.findOne({
                $or: [
                    { userId: mongoose.Types.ObjectId(call.request.getUserId()) },
                    // { deviceId: mongoose.Types.ObjectId(call.request.getDeviceId()) },
                ],
            });
            if (!favorite) {
                const newFavorite = new FavoriteModel();
                newFavorite.userId = mongoose.Types.ObjectId(call.request.getUserId());
                // newFavorite.deviceId = mongoose.Types.ObjectId(call.request.getDeviceId());
                newFavorite.items?.push(mongoose.Types.ObjectId(call.request.getProductId()));
                newFavorite.save().then(async () => {
                    callback(null, new Empty());
                    return;
                });
            } else {
                if (!favorite.items) favorite.items = [];
                const fIndex = favorite.items.findIndex((sItem) => sItem.toHexString() == call.request.getProductId());
                if (fIndex < 0) favorite.items?.push(mongoose.Types.ObjectId(call.request.getProductId()));
                favorite.markModified('items');
                favorite.save().then(async () => {
                    callback(null, new Empty());
                    return;
                });
            }
        } catch (error) {
            console.error('!!! add Favorite in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public remove(call: ServerUnaryCall<OwnerId>, callback: sendUnaryData<Empty>): void {
        try {
            FavoriteModel.findOneAndUpdate(
                {
                    $or: [
                        { userId: mongoose.Types.ObjectId(call.request.getUserId()) },
                        // { deviceId: mongoose.Types.ObjectId(call.request.getDeviceId()) },
                    ],
                },
                {
                    $pull: { items: mongoose.Types.ObjectId(call.request.getProductId()) },
                },
            ).then(() => {
                callback(null, new Empty());
            });
        } catch (error) {
            console.error('!!! delete Favorite in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public list(call: ServerUnaryCall<Filter>, callback: sendUnaryData<AppList>): void {
        const countryId = call.request.getBaseinfo()!.getCountryId();
        try {
            const aggre = FavoriteModel.aggregate([
                { $match: { userId: mongoose.Types.ObjectId(call.request.getBaseinfo()!.getUserId()) } },
            ]).lookup({
                from: 'viewproducts',
                as: 'Products',
                let: { items: '$items' },
                pipeline: [
                    {
                        $match: {
                            $expr: {
                                $in: ['$_id', '$$items'],
                            },
                        },
                    },
                    {
                        $lookup: {
                            from: 'prices',
                            as: 'prices',
                            let: { dSkuId: '$defaultSkuId' },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [
                                                {
                                                    $eq: ['$skuId', '$$dSkuId'],
                                                },
                                                {
                                                    $eq: ['$countryId', Types.ObjectId(countryId)],
                                                },
                                            ],
                                        },
                                    },
                                },
                            ],
                        },
                    },

                    {
                        $lookup: {
                            from: 'viewquantites',
                            localField: 'defaultSkuId',
                            foreignField: '_id.skuId',
                            as: 'quantities',
                        },
                    },
                    {
                        $addFields: {
                            price: {
                                $cond: {
                                    if: { $gt: [{ $size: '$prices' }, 0] },
                                    then: { $first: '$prices.price' },
                                    else: '$price.price',
                                },
                            },
                            quantity: { $first: `$quantities.quantity.${countryId}` },
                        },
                    },
                ],
            });
            CommonFilterConvert(call.request, aggre, [], call.request.getBaseinfo()!.getLanguage()).then(
                async (products: any) => {
                    const orderList = new AppList();
                    await Promise.all(
                        products[0].paginatedResults.map(async (favorite: any) => {
                            if (favorite && favorite.Products.length > 0) {
                                orderList.setItemsList(
                                    favorite.Products.map((product: any) => {
                                        const price =
                                            (product.price ?? 0) * call.request.getBaseinfo()!.getCurrencyRate();
                                        const priceObject = {
                                            originalPrice: price.toString(),
                                            offPrice: price.toString(),
                                            title: '',
                                            expire_at: 0,
                                            currencySymbol: call.request.getBaseinfo()!.getCurrencySymbol(),
                                        };
                                        // if (product.isDiscountable) {
                                        //     priceObject = {
                                        //         originalPrice: price.toString(),
                                        //         offPrice: (price * 0.95).toString(),
                                        //         title: 'Special Sell',
                                        //         expire_at: 0,
                                        //     };
                                        // }

                                        return Struct.fromJavaScript({
                                            id: product._id.toString(),
                                            name: product.name[call.request.getBaseinfo()!.getLanguage()] ?? '',
                                            image: product.image ?? null,
                                            price: priceObject,
                                            isFavorite: true,
                                            category:
                                                product.categories && product.categories.length > 0
                                                    ? {
                                                          id: product.categories[0]._id.toString(),
                                                          name:
                                                              product.categories[0].name[
                                                                  call.request.getBaseinfo()!.getLanguage()
                                                              ] ?? '',
                                                          image: product.categories[0].image ?? null,
                                                      }
                                                    : {},
                                        });
                                    }),
                                );
                            }
                        }),
                    );
                    callback(null, orderList);
                },
            );
        } catch (error) {
            console.error('!!! app list Order in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
