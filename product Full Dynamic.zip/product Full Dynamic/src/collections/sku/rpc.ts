/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData, status } from 'grpc';
import SkuClass from './model';
import SkuViewClass from './view';
import { ISku_Server } from '../../protoDef/sku_grpc_pb';
import { SkuImage } from '../../protoDef/sku_pb';
import { getModelForClass } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Types } from 'mongoose';
import BaseServer from '../common/baseServer';
/**
 * Create model of Sku Class.
 */
const SkuModel = getModelForClass(SkuClass);
const SkuView = getModelForClass(SkuViewClass);

/**
 * Sku gRPC server.
 */
export default class SkuServer extends BaseServer implements ISku_Server {
    protected model = SkuModel;
    protected view = SkuView;
    protected async dao(item: any, _isDetailed: boolean, _isList: boolean) {
        let price = 0;
        if (item && item.price) price = item.price.price.toString();
        const nowd = new Date();
        nowd.setHours(nowd.getHours() + 72);
        return {
            id: item._id.toString(),
            isActive: item.isActive ?? false,
            barcode: item.barcode ?? '',
            sku: item.sku ?? '',
            price: {
                originalPrice: price.toString(),
                offPrice: price.toString(),
                title: '',
                expire_at: 0,
            },
            'product.name': item.product?.name ?? null,
            images: await Promise.all(
                item.images.map((image: any) => ({
                    order: image.order.toString(),
                    image: image.image,
                })),
            ),
            variations: await Promise.all(
                item.VariationItems.map(async (vset: any) => ({
                    id: vset.Variation._id.toString(),
                    name: vset.Variation.name ?? null,
                    item: {
                        id: vset._id.toString(),
                        name: vset.name ?? null,
                        values: vset.values,
                    },
                })),
            ),

            createdAt: item.createdAt?.getTime() ?? 0,
            updatedAt: item.updatedAt?.getTime() ?? 0,
        };
    }
    protected async appDao(item: any, _language: string, _isDetailed: boolean, _isList: boolean) {
        return {
            id: item._id.toString(),
        };
    }
    /**
     * Add new image.
     * @param   id
     * @param   imageName
     */
    public async addImage(call: ServerUnaryCall<SkuImage>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Sku ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            //const modifiedStr = [];
            const sku = await SkuModel.findById(call.request.getId());
            if (!sku) {
                callback({ code: 404, message: 'Sku Not found.', name: 'NOT found' }, null);
                return;
            }
            sku.images?.push({ order: call.request.getOrder(), image: call.request.getImage()?.toJavaScript() });
            sku.markModified('images');
            sku.save()
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (error) {
            console.error('!!! add image sku in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
    /**
     * Remove an image of sku.
     * @param   id
     * @param   imageName
     */
    public async deleteImage(call: ServerUnaryCall<SkuImage>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Sku ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            //const modifiedStr = [];
            const sku = await SkuModel.findById(call.request.getId());
            if (!sku) {
                callback({ code: 404, message: 'Sku Not found.', name: 'NOT found' }, null);
                return;
            }
            //sku.images?.delete(call.request.getImage());
            sku.markModified('images');
            sku.save()
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (error) {
            console.error('!!! delete image sku in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
