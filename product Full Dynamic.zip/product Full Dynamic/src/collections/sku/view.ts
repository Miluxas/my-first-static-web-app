export default class ViewSku {
    public _id!: string;
}
