import { prop, getModelForClass, mongoose, DocumentType, modelOptions, Severity, Ref } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';
import BaseModel from '../common/baseModel';
import Product from '../product/model';
import VariationItemClass from '../variation/itemModel';

const VariationItemModel = getModelForClass(VariationItemClass);
const ProductModel = getModelForClass(Product);

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
class Image {
    @prop({ type: mongoose.Schema.Types.Mixed })
    public image?: Record<string, JavaScriptValue>;
    @prop({})
    public order?: number;
}
export class VariationSet {
    @prop({})
    public variationId!: mongoose.Types.ObjectId;
    @prop({})
    public itemId!: mongoose.Types.ObjectId;
}

export default class SKU extends BaseModel {
    @prop({ ref: mongoose.Types.ObjectId, required: true })
    public productId!: Ref<mongoose.Types.ObjectId>;

    @prop({})
    public sku?: string;

    @prop({ type: Image })
    public images?: Image[];

    @prop({ type: VariationSet })
    public variations?: VariationSet[];

    @prop({})
    public barcode?: string;

    @prop({ default: true })
    public isDiscountable?: boolean;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('productId', 'sku', 'variations', 'barcode', 'isDiscountables');
        return base;
    }

    public async getDefaultSku(): Promise<string> {
        const str: string[] = [];

        const prodObj = await ProductModel.findById(this.productId);
        let prodName = prodObj?.name.get('en') ?? '';
        prodName = prodName.split(' ').join('');
        prodName = prodName.toLowerCase();
        str.push(prodName);

        if (this.variations) {
            for (let i = 0; i < this.variations.length; i++) {
                const variObj = await VariationItemModel.findById(this.variations[i].itemId);
                let itemName = variObj?.name.get('en') ?? '';
                itemName = itemName.split(' ').join('');
                itemName = itemName.toLowerCase();
                str.push(itemName);
            }
        }
        return str.join('_');
    }

    public static async RegenerateSku(fSku: DocumentType<SKU>, varis: VariationSet[]): Promise<number> {
        //console.log('varis count :', varis.length, this.variations?.length);
        //if (varis.length != this.variations?.length) return false;
        // const Model = getModelForClass(SKU);
        // const fSku = await Model.findById(skuId);
        if (fSku)
            if (fSku.variations) {
                const isArr = (fSku.variations ?? []).map((element) =>
                    varis.map((vari) => element.itemId.toHexString() == vari.itemId.toHexString()).some((res) => res),
                );
                console.log('isArr : ', fSku.id, isArr);
                if (isArr.every((result) => result)) {
                    console.log('isArr every one is true');
                    console.log(varis.length, fSku.variations?.length);
                    if (varis.length > fSku.variations?.length) {
                        console.log('adding variation to object ...');
                        varis.forEach((v) => {
                            if (
                                !fSku.variations
                                    ?.map((vari) => vari.itemId.toHexString() == v.itemId.toHexString())
                                    .some((re) => re)
                            )
                                fSku.variations?.push(v);
                        });
                        console.log(fSku.variations);
                        fSku.markModified('variations');
                        fSku.sku = await fSku.getDefaultSku();
                        await fSku.save();
                        return 2;
                    } else return 1;
                }
            }
        return 0;
    }
}
