/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import TagClass from './model';
import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import Translate from '../common/multyLang';

const TagModel = getModelForClass(TagClass);
/**
 * Tag gRPC server.
 */
export default class TagServer extends BaseServer {
    protected model = TagModel;
    protected searchOn = ['title'];
    protected async dao(item: any, isDetailed: boolean, isList: boolean) {
        return TagServer.dao(item, isDetailed, isList);
    }
    protected async appDao(item: any, language: string, isDetailed: boolean, isList: boolean) {
        return TagServer.appDao(item, language, isDetailed, isList);
    }
    public static async dao(item: any, _isDetailed: boolean, _isList: boolean) {
        return {
            id: item._id.toString(),
            title: item.title ?? '',
            createdAt: item.createdAt?.getTime() ?? 0,
            updatedAt: item.updatedAt?.getTime() ?? 0,
        };
    }
    public static async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean) {
        return {
            id: item._id.toString(),
            name: Translate(item.name, language),
            logo: item.logo ?? null,
        };
    }
}
