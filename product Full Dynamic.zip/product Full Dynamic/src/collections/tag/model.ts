import { prop, index, modelOptions, Severity } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';

@index({ title: 'text' })
@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Tag extends BaseModel {
    @prop({ type: String, required: true, unique: true })
    public title!: Map<string, string>;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('title');
        return base;
    }
}
