import { prop, getModelForClass, modelOptions, Severity, Ref } from '@typegoose/typegoose';
import Attribute from '../attribute/model';
import BaseModel from '../common/baseModel';

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
class Category extends BaseModel {
    @prop()
    public order?: number;

    @prop({ ref: Category })
    public subCategoriesId?: Ref<Category>[];

    @prop({ ref: Attribute })
    public defaultAttributeIds?: Ref<Attribute>[];

    public async AddParentAttributes(callback: CallableFunction) {
        const parents = await Model.find({ subCategoriesId: { $elemMatch: this } });
        if (parents) {
            await Promise.all(
                parents.map(async (parent) => {
                    if (parent.defaultAttributeIds)
                        await Promise.all(
                            parent.defaultAttributeIds.map((atr) => {
                                callback(atr);
                            }),
                        );
                }),
            );
        }
    }
    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('order', 'subCategoriesId', 'defaultAttributeIds');
        return base;
    }
}

const Model = getModelForClass(Category);

export default Category;
