/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData, status } from 'grpc';
import CategoryClass from './model';
import CategoryViewClass from './view';
import { ICategory_Server } from '../../protoDef/category_grpc_pb';
import { CategoryAndParentId, CategoryAttributes, Attributes, CategoryOrder } from '../../protoDef/category_pb';
import { AppList, Filter, Id, Ids } from '../../protoDef/common_pb';
import { getModelForClass, mongoose } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Types } from 'mongoose';
import BaseServer from '../common/baseServer';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import Translate from '../common/multyLang';
import CommonFilterConvert from '../common/filterConvert';
import ToAppList from '../common/appListDecorator';

/**
 * Create model of Category Class.
 */
const CategoryModel = getModelForClass(CategoryClass);
const CategoryView = getModelForClass(CategoryViewClass);

/**
 * Category gRPC server.
 */
export default class CategoryServer extends BaseServer implements ICategory_Server {
    protected model = CategoryModel;
    protected view = CategoryView;
    protected searchOn = ['name'];
    protected async dao(category: any, isDetailed: boolean, isList: boolean): Promise<any> {
        return CategoryServer.dao(category, isDetailed, isList);
    }
    protected async appDao(category: any, language: string, isDetailed: boolean, isList: boolean): Promise<any> {
        return CategoryServer.appDao(category, language, isDetailed, isList);
    }
    public static async dao(category: any, isDetailed: boolean, _isList: boolean): Promise<any> {
        category.subCategories = isDetailed
            ? await Promise.all(
                  (category.subCategories ?? []).map(async (sc: any) => await this.dao(sc, isDetailed, false)),
              )
            : [];

        category.defaultAttributes = await Promise.all(
            (category.defaultAttributes ?? []).map((attri: any) => ({
                name: attri.name,
                _id: attri._id.toString(),
            })),
        );

        return BaseServer.objectDao(category);
    }

    private async daoTree(category: any): Promise<any> {
        const subCat: any[] = [];
        await Promise.all(
            (category.subCategoriesIdId ?? []).map(async (scId: any) => {
                const sc = await CategoryView.aggregate([
                    { $match: { isDeleted: false, _id: mongoose.Types.ObjectId(scId) } },
                ]);
                if (sc.length > 0) subCat.push(await this.daoTree(sc[0]));
            }),
        );

        category.defaultAttributes = await Promise.all(
            (category.defaultAttributes ?? []).map((attri: any) => ({
                name: attri.name,
                _id: attri._id.toString(),
            })),
        );
        category.subCategories = subCat;
        return BaseServer.objectDao(category);
    }
    public static async appDao(category: any, language: string, isDetailed: boolean, _isList: boolean): Promise<any> {
        return {
            id: category._id.toString(),
            createdBy: category.createdBy?.toHexString() ?? '',
            storeId: category.storeId?.toHexString() ?? '',
            name: Translate(category.name, language),
            image: category.image ?? null,
            defaultAttributes: await Promise.all(
                (category.defaultAttributes ?? []).map((attri: any) => ({
                    name: attri.name[language] ?? '',
                    _id: attri._id.toString(),
                })),
            ),

            subCategories: isDetailed
                ? await Promise.all(
                      (category.subCategories ?? []).map(
                          async (sc: any) => await this.appDao(sc, language, isDetailed, false),
                      ),
                  )
                : [],
            parentCategory: category.parentCategory
                ? await this.appDao(category.parentCategory, language, false, false)
                : {},
        };
    }

    public async getTree(_call: ServerUnaryCall<Id>, callback: sendUnaryData<Struct>): Promise<void> {
        try {
            this.view.aggregate();
            const result: any[] = [];
            await CategoryView.aggregate([{ $match: { isDeleted: false, parentCategory: undefined } }]).then(
                async (list: any) => {
                    await Promise.all(
                        list.map(async (cat: any) => {
                            if (cat) result.push(await this.daoTree(cat));
                        }),
                    );
                },
            );
            callback(null, Struct.fromJavaScript({ tree: result }));
        } catch (error) {
            console.error('!!! get ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public appList(call: ServerUnaryCall<Filter>, callback: sendUnaryData<AppList>): void {
        try {
            CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                this.view.aggregate([{ $match: { productsCount: { $gt: 0 }, isDeleted: false } }]),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ToAppList(
                        list,
                        async (item) =>
                            Struct.fromJavaScript(
                                await this.appDao(item, call.request.getBaseinfo()!.getLanguage(), false, true),
                            ),
                        call.request.getFilter()?.toJavaScript().pagination,
                    ),
                );
            });
        } catch (error) {
            console.error('!!! appList ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async setParent(call: ServerUnaryCall<CategoryAndParentId>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            if (!Types.ObjectId.isValid(call.request.getParentId())) {
                callback({ code: 400, message: 'Wrong Parent Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const parentCat = await CategoryModel.findOne({
                _id: call.request.getParentId(),
            });
            const mainCat = await CategoryModel.findOne({
                _id: call.request.getId(),
            });
            if (mainCat && parentCat) {
                /** Find category that have a reverse direction. */
                const isExist = await CategoryModel.findOne({
                    subCategoriesIdId: Types.ObjectId(call.request.getId()),
                    _id: call.request.getParentId(),
                });
                if (!isExist)
                    CategoryModel.findByIdAndUpdate(
                        call.request.getParentId(),
                        {
                            $push: { subCategoriesIdId: Types.ObjectId(call.request.getId()) },
                        },
                        { new: true },
                    ).then(() => {
                        callback(null, new Empty());
                        return;
                    });
            } else callback(null, new Empty());
        } catch (error) {
            console.error('!!! set parent category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async setOrder(call: ServerUnaryCall<CategoryOrder>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const parentCat = await CategoryModel.findOne({
                subCategoriesIdId: Types.ObjectId(call.request.getId()),
            });
            if (parentCat) {
                parentCat.subCategoriesId = parentCat.subCategoriesId?.filter(
                    (sId) => sId != Types.ObjectId(call.request.getId()),
                );
                parentCat.subCategoriesId?.splice(call.request.getOrder(), 0, Types.ObjectId(call.request.getId()));
                parentCat.markModified('subCategoriesIdId');
                parentCat.save().then(() => {
                    callback(null, new Empty());
                });
            } else {
                await CategoryModel.findByIdAndUpdate(call.request.getId(), { order: call.request.getOrder() }).then(
                    () => {
                        callback(null, new Empty());
                    },
                );
            }
        } catch (error) {
            console.error('!!! set parent category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /**
     * Remove the parent Id of category by Id.
     * @param   id
     */
    public async deleteParent(call: ServerUnaryCall<Id>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const mainCat = await CategoryModel.findOne({
                _id: call.request.getId(),
            });
            if (mainCat) {
                CategoryModel.findOneAndUpdate(
                    { subCategoriesIdId: Types.ObjectId(call.request.getId()) },
                    { $pull: { subCategoriesIdId: Types.ObjectId(call.request.getId()) } },
                    { new: true },
                )
                    .then(() => {
                        callback(null, new Empty());
                        return;
                    })
                    .catch((err) => {
                        callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                        return;
                    });
            } else callback(null, new Empty());
        } catch (error) {
            console.error('!!! delete parent category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /**
     * Add an attribute to a category.
     * @param   id
     * @param   defaultAttributeIdsList
     */
    public async addAttribute(
        call: ServerUnaryCall<CategoryAttributes>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const mainCat = await CategoryModel.findOne({
                _id: call.request.getId(),
            });
            if (!mainCat) {
                callback({ code: 404, message: 'Category Not found.', name: 'NOT found' }, null);
                return;
            }
            await Promise.all(
                call.request.getAttributesList().map(async (att) => {
                    mainCat.defaultAttributeIds?.push(Types.ObjectId(att));
                }),
            );
            mainCat.markModified('defaultAttributeIds');
            mainCat.save().then(() => {
                callback(null, new Empty());
                return;
            });
        } catch (error) {
            console.error('!!! add attribute category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /**
     * Remove an attribute from category.
     * @param   id
     * @param   defaultAttributeIdsList
     */
    public async deleteAttribute(
        call: ServerUnaryCall<CategoryAttributes>,
        callback: sendUnaryData<Empty>,
    ): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Category ID structure.', name: 'WRONG Id' }, null);
                return;
            }
            const mainCat = await CategoryModel.findOne({
                _id: call.request.getId(),
            });
            if (!mainCat) {
                callback({ code: 404, message: 'Category Not found.', name: 'NOT found' }, null);
                return;
            }
            mainCat.defaultAttributeIds = mainCat.defaultAttributeIds?.filter(
                (attrib) => !call.request.getAttributesList().includes(attrib?.toString() ?? ''),
            );
            mainCat.markModified('defaultAttributeIds');
            mainCat
                .save()
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (error) {
            console.error('!!! delete attribute category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async getAttributes(call: ServerUnaryCall<Ids>, callback: sendUnaryData<Attributes>): Promise<void> {
        try {
            const mainCat = await CategoryModel.find({
                _id: { $in: call.request.getIdList() },
            });
            const result = new Attributes();

            const attriMap = new Map<string, string>();

            await Promise.all(
                mainCat.map(async (cat) => {
                    const catModel = await CategoryModel.findById(cat);
                    if (catModel) {
                        if (catModel.defaultAttributeIds)
                            await Promise.all(
                                catModel.defaultAttributeIds.map((att) => {
                                    result.addAttributes(JSON.stringify(att));
                                }),
                            );
                        catModel.AddParentAttributes((att: any) => {
                            attriMap.set(att.id, JSON.stringify(att.name));
                        });
                    }
                }),
            );
            attriMap.forEach((val) => {
                result.addAttributes(JSON.stringify(val));
            });
            callback(null, result);
            return;
        } catch (error) {
            console.error('!!! get defaultAttributeIds category in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
