import { mongoose, Ref } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';
import Attribute from '../attribute/model';
import Category from './model';

export default class ViewCategory {
    public _id!: mongoose.Types.ObjectId;
    public name!: Map<string, string>;
    public image?: Record<string, JavaScriptValue>;
    public order?: number;
    public subCategoriesId?: Ref<Category>[];
    public attributeIds?: Ref<Attribute>[];
}
