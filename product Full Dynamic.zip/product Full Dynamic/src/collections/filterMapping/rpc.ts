/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */

import FilterMappingClass from './model';
import { IFilterMapping_Server } from '../../protoDef/filter_mapping_grpc_pb';

import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import { sendUnaryData, ServerUnaryCall } from 'grpc';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';

import VariationViewClass from '../variation/view';
import BadgeModelClass from '../badge/model';
import BrandModelClass from '../brand/model';
import CategoryModelClass from '../category/model';
import { Filter } from '../../protoDef/common_pb';
import Translate from '../common/multyLang';

/**
 * Create model of FilterMapping Class.
 */
const FilterMappingModel = getModelForClass(FilterMappingClass);
const VariationView = getModelForClass(VariationViewClass);
const BadgeModel = getModelForClass(BadgeModelClass);
const BrandModel = getModelForClass(BrandModelClass);
const CategoryModel = getModelForClass(CategoryModelClass);

/**
 * FilterMapping gRPC server.
 */
export default class FilterMappingServer extends BaseServer implements IFilterMapping_Server {
    protected model = FilterMappingModel;
    protected searchOn = ['name', 'value'];
    protected async dao(item: any, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: item._id.toString(),
            title: item.title ?? {},
        };
    }

    protected async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: item._id.toString(),
            title: Translate(item.name, language),
        };
    }

    public async appGetDynamicFilter(call: ServerUnaryCall<Filter>, callback: sendUnaryData<Struct>): Promise<void> {
        const filtersList: any[] = [];
        const sortsList: any[] = [];
        const requestFilterObject = call.request.getFilter()?.toJavaScript()['filter'] ?? new Object();
        console.log(requestFilterObject, requestFilterObject['brand._id'], !requestFilterObject['filter.brand._id']);
        const res = { filters: filtersList, sorts: sortsList };
        sortsList.push({
            name: 'Newest',
            sort: { createdBy: -1 },
        });
        sortsList.push({
            name: 'Lowest Price',
            sort: { price: 1 },
        });
        sortsList.push({
            name: 'Highest Price',
            sort: { price: -1 },
        });

        await BadgeModel.aggregate([{ $match: { isDeleted: false } }]).then(async (badges: any) => {
            const items: any[] = [];
            const filter = {
                name: 'Badge',
                search: 'badges._id',
                items: items,
            };
            await badges.map(async (badge: any, index: number) => {
                filter.items[index] = {
                    id: badge._id.toHexString(),
                    name: badge.title[call.request.getBaseinfo()!.getLanguage()] ?? '',
                };
            });
            res.filters.push(filter);
        });
        if (!requestFilterObject['brand._id'])
            await BrandModel.aggregate([{ $match: { isDeleted: false } }]).then(async (brands: any) => {
                const items: any[] = [];

                const filter = {
                    name: 'Brand',
                    search: 'brand._id',
                    items: items,
                };
                await brands.map(async (brand: any, index: number) => {
                    filter.items[index] = {
                        id: brand._id.toHexString(),
                        name: brand.name[call.request.getBaseinfo()!.getLanguage()] ?? '',
                    };
                });
                res.filters.push(filter);
            });
        if (!requestFilterObject['categories._id'])
            await CategoryModel.aggregate([{ $match: { isDeleted: false } }]).then(async (categories: any) => {
                const items: any[] = [];

                const filter = {
                    name: 'Category',
                    search: 'categories._id',
                    items: items,
                };
                await categories.map(async (category: any, index: number) => {
                    filter.items[index] = {
                        id: category._id.toHexString(),
                        name: category.name[call.request.getBaseinfo()!.getLanguage()] ?? '',
                    };
                });
                res.filters.push(filter);
            });
        const filterCount = res.filters.length;
        await VariationView.aggregate([{ $match: { isDeleted: false } }]).then(async (varis: any) => {
            await varis.map(async (vari: any, index: number) => {
                const items: any[] = [];

                const searchKeyStr = `'variations.variationId':'${vari._id.toString()}','variations.itemsId'`;

                if (!requestFilterObject[searchKeyStr] ?? '') {
                    const filter = {
                        //id: vari._id.toHexString(),
                        name: vari.name[call.request.getBaseinfo()!.getLanguage()] ?? '',
                        search: searchKeyStr,
                        items: items,
                        type: vari.type,
                    };
                    await vari.Items.map((item: any, ind: number) => {
                        filter.items[ind] = {
                            id: item._id.toHexString(),
                            name: item.name[call.request.getBaseinfo()!.getLanguage()] ?? '',
                            values: item.values,
                        };
                    });
                    res.filters[filterCount + index] = filter;
                }
            });
        });
        callback(null, Struct.fromJavaScript(res));
    }
}
