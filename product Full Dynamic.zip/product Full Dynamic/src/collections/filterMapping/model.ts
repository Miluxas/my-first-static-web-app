import { prop } from '@typegoose/typegoose';
import { Types } from 'mongoose';
import BaseModel from '../common/baseModel';

export default class FilterMapping extends BaseModel {
    // variation or attribute Ids
    @prop({ ref: Types.ObjectId })
    public titleItemsId?: Types.ObjectId[];

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('titleItemsId');
        return base;
    }
}
