/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import FilterMappingItemClass from './model';

import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';

import Translate from '../common/multyLang';
/**
 * Create model of FilterMappingItem Class.
 */
const FilterMappingItemModel = getModelForClass(FilterMappingItemClass);

/**
 * FilterMappingItem gRPC server.
 */
export default class FilterMappingItemServer extends BaseServer {
    protected model = FilterMappingItemModel;
    protected searchOn = ['name', 'value'];
    protected async dao(item: any, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: item._id.toString(),
            title: item.title ?? {},
        };
    }

    protected async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            id: item._id.toString(),
            title: Translate(item.name, language),
        };
    }
}
