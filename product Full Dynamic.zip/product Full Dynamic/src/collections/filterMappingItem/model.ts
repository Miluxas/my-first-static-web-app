import { prop } from '@typegoose/typegoose';
import { Types } from 'mongoose';
import BaseModel from '../common/baseModel';

export default class FilterMappingItem extends BaseModel {
    @prop({ type: String, required: true })
    public title!: Map<string, string>;

    // variation or attribute Ids
    @prop({ ref: Types.ObjectId })
    public valueItemsId?: Types.ObjectId[];

    @prop({ ref: Types.ObjectId })
    public filterMappingId?: Types.ObjectId;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('title', 'valueItemsId', 'filterMappingId');
        return base;
    }
}
