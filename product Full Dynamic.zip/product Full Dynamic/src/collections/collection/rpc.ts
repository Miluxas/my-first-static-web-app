/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-array-constructor */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData } from 'grpc';
import CollectionClass from './model';
import ProductViewClass from '../product/view';
import { ICollection_Server } from '../../protoDef/collection_grpc_pb';
import { CollectionId } from '../../protoDef/collection_pb';
import { getModelForClass, mongoose } from '@typegoose/typegoose';
import { Aggregate, Types } from 'mongoose';
import CommonFilterConvert from '../common/filterConvert';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import ProductServer from '../product/rpc';
import BaseServer from '../common/baseServer';
import BrandServer from '../brand/rpc';
import CategoryServer from '../category/rpc';
import BrandClass from '../brand/model';
import CategoryViewClass from '../category/view';
import Translate from '../common/multyLang';
/**
 * Create model of Collection Class.
 */
const CollectionModel = getModelForClass(CollectionClass);
const ProductView = getModelForClass(ProductViewClass);
const BrandView = getModelForClass(BrandClass);
const CategoryView = getModelForClass(CategoryViewClass);
/**
 * Collection gRPC server.
 */
export default class CollectionServer extends BaseServer implements ICollection_Server {
    protected model = CollectionModel;
    protected async dao(collection: any, isDetailed: boolean, isList: boolean, call: any) {
        return CollectionServer.dao(collection, isDetailed, isList, call);
    }
    public static async dao(collection: any, _isDetailed: boolean, _isList: boolean, _call: any) {
        return {
            image: collection.image ?? null,
            id: collection._id.toString(),
            filter: collection.filter ?? {},
            name: collection.name,
            createdAt: collection.createdAt?.getTime() ?? 0,
            updatedAt: collection.updatedAt?.getTime() ?? 0,
        };
    }
    protected async appDao(
        collection: any,
        language: string,
        isDetailed: boolean,
        isList: boolean,
        call: any,
    ): Promise<any> {
        return CollectionServer.appDao(collection, language, isDetailed, isList, call);
    }

    public static async appDao(
        collection: any,
        language: string,
        isDetailed: boolean,
        isList: boolean,
        call: any,
    ): Promise<any> {
        if (isList) {
            return {
                image: collection.image ?? null,
                id: collection._id.toString(),
                name: Translate(collection.name, language),
                items: [],
            };
        } else {
            let pagination = { page: 0, limit: 100 };
            try {
                pagination = { page: call?.request.getPage() ?? 0, limit: call?.request.getLimit() ?? 100 };
                if (call?.request.getPage() !== undefined)
                    Object.assign(collection.filter ?? {}, {
                        pagination: pagination,
                    });
            } catch (error) {}
            try {
                const extraFilter = call?.request.getFilter().toJavaScript();
                if (extraFilter !== undefined) {
                    const onlyFilter = collection.filter?.filter ?? {};
                    Object.assign(onlyFilter, extraFilter);
                    collection.filter.filter = onlyFilter;
                }
            } catch (error) {
                console.log(error);
            }

            let gList: any = [];
            if (isDetailed && collection.modelName == 'product')
                gList = await CollectionServer.generateAppList(
                    collection.modelName,
                    collection.filter,
                    call.request.getUserId(),
                    language,
                    call,
                );

            return {
                item: {
                    image: collection.image ?? {},
                    id: collection._id.toString(),
                    name: Translate(collection.name, language),
                    items: gList.itemsList ?? [],
                },
                hasNext: gList.hasNext ?? false,
            };
        }
    }
    public appGetPagination(call: ServerUnaryCall<CollectionId>, callback: sendUnaryData<Struct>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    { code: 400, message: 'Wrong ' + this.model.modelName + ' ID structure.', name: 'WRONG Id' },
                    null,
                );
                return;
            }
            CollectionModel.aggregate([
                { $match: { isDeleted: false, _id: mongoose.Types.ObjectId(call.request.getId()) } },
            ]).then(async (list: any) => {
                if (list.length == 0) {
                    callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                    return;
                }

                callback(
                    null,
                    Struct.fromJavaScript(
                        await this.appDao(
                            list[0],
                            call.request.getBaseinfo()!.getLanguage() ?? 'en',
                            true,
                            false,
                            call,
                        ),
                    ),
                );
            });
        } catch (error) {
            console.error('!!! get ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    static async generateList(modelName: string, filter: any, userId: string, language: string, call: any) {
        // eslint-disable-next-line @typescript-eslint/no-array-constructor
        const itemsList: any = [];
        filter = this.StdFilterObject(filter ?? {});
        let aggre = new Aggregate();
        switch (modelName) {
            case 'brand':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    BrandView.aggregate([{ $match: { isDeleted: false } }]),
                    ['title'],
                    language,
                );
                await aggre.then(async (brands: any) => {
                    await Promise.all(
                        brands[0].paginatedResults.map(async (brand: any) => {
                            if (brand) {
                                itemsList.push(BaseServer.objectDao(brand));
                            }
                        }),
                    );
                });
                break;
            case 'product':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    ProductView.aggregate([{ $match: { isDeleted: false } }]),
                    ['name', 'description', 'Attributes.name', 'Attributes.value'],
                    language,
                );
                await aggre.then(async (products: any) => {
                    await Promise.all(
                        products[0].paginatedResults.map(async (product: any) => {
                            if (product) {
                                itemsList.push(
                                    await ProductServer.ModelToObject(
                                        product,
                                        userId,
                                        call.request.getBaseinfo()!.getCurrencyRate(),
                                        call.request.getBaseinfo()!.getCurrencySymbol(),
                                    ),
                                );
                            }
                        }),
                    );
                });
                break;
            case 'category':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    CategoryView.aggregate([{ $match: { isDeleted: false } }]),
                    ['name'],
                    language,
                );
                await aggre.then(async (categories: any) => {
                    await Promise.all(
                        categories[0].paginatedResults.map(async (category: any) => {
                            if (category) {
                                itemsList.push(await CategoryServer.dao(category, false, false));
                            }
                        }),
                    );
                });
                break;
            case 'collection':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    CollectionModel.aggregate([{ $match: { isDeleted: false } }]),
                    ['name'],
                    language,
                );
                await aggre.then(async (collections: any) => {
                    await Promise.all(
                        collections[0].paginatedResults.map(async (collection: any, index: any) => {
                            if (collection) {
                                itemsList[index] = await this.dao(collection, false, true, call);
                            }
                        }),
                    );
                });
                break;
            default:
                break;
        }
        return itemsList;
    }
    static async generateAppList(modelName: string, filter: any, userId: string, language: string, call: any) {
        // eslint-disable-next-line @typescript-eslint/no-array-constructor
        const itemsList: any = [];
        let hasNext = false;
        filter = this.StdFilterObject(filter ?? {});
        let aggre = new Aggregate();
        switch (modelName) {
            case 'brand':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    BrandView.aggregate([{ $match: { isDeleted: false } }]),
                    ['title'],
                    language,
                );
                await aggre.then(async (brands: any) => {
                    hasNext =
                        (brands[0]?.totalCount[0]?.count ?? 0) >
                        ((filter?.pagination?.page ?? 0) + 1) * (filter?.pagination?.limit ?? 1000);
                    await Promise.all(
                        brands[0].paginatedResults.map(async (brand: any, index: any) => {
                            if (brand) {
                                itemsList[index] = await BrandServer.appDao(brand, language, false, true);
                            }
                        }),
                    );
                });
                break;
            case 'product':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    ProductView.aggregate([{ $match: { isDeleted: false } }])
                        .lookup({
                            from: 'prices',
                            as: 'prices',
                            let: { dSkuId: '$defaultSkuId' },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [
                                                {
                                                    $eq: ['$skuId', '$$dSkuId'],
                                                },
                                                {
                                                    $eq: [
                                                        '$countryId',
                                                        Types.ObjectId(call.request.getBaseinfo()!.getCountryId()),
                                                    ],
                                                },
                                            ],
                                        },
                                    },
                                },
                            ],
                        })
                        .lookup({
                            from: 'viewquantites',
                            localField: 'defaultSkuId',
                            foreignField: '_id.skuId',
                            as: 'quantities',
                        })
                        .addFields({
                            price: {
                                $cond: {
                                    if: { $gt: [{ $size: '$prices' }, 0] },
                                    then: { $first: '$prices.price' },
                                    else: '$price.price',
                                },
                            },
                            quantity: { $first: `$quantities.quantity.${call.request.getBaseinfo()!.getCountryId()}` },
                        }),
                    ['name', 'description', 'Attributes.name', 'Attributes.value'],
                    language,
                );
                await aggre.then(async (products: any) => {
                    hasNext =
                        (products[0]?.totalCount[0]?.count ?? 0) >
                        ((filter?.pagination?.page ?? 0) + 1) * (filter?.pagination?.limit ?? 1000);

                    await Promise.all(
                        products[0].paginatedResults.map(async (product: any, index: any) => {
                            if (product) {
                                itemsList[index] = await ProductServer.AppModelToObject(
                                    product,
                                    language,
                                    userId,
                                    call.request.getBaseinfo()!.getCurrencyRate(),
                                    call.request.getBaseinfo()!.getCurrencySymbol(),
                                );
                            }
                        }),
                    );
                });
                break;
            case 'category':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    CategoryView.aggregate([{ $match: { isDeleted: false } }]),
                    ['name'],
                    language,
                );
                await aggre.then(async (categories: any) => {
                    hasNext =
                        (categories[0]?.totalCount[0]?.count ?? 0) >
                        ((filter?.pagination?.page ?? 0) + 1) * (filter?.pagination?.limit ?? 1000);

                    await Promise.all(
                        categories[0].paginatedResults.map(async (category: any, index: any) => {
                            if (category) {
                                itemsList[index] = await CategoryServer.appDao(category, language, false, false);
                            }
                        }),
                    );
                });
                break;
            case 'collection':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    CollectionModel.aggregate([{ $match: { isDeleted: false } }]),
                    ['name'],
                    language,
                );
                await aggre.then(async (collections: any) => {
                    hasNext =
                        (collections[0]?.totalCount[0]?.count ?? 0) >
                        ((filter?.pagination?.page ?? 0) + 1) * (filter?.pagination?.limit ?? 1000);

                    await Promise.all(
                        collections[0].paginatedResults.map(async (collection: any, index: any) => {
                            if (collection) {
                                itemsList[index] = await CollectionServer.appDao(
                                    collection,
                                    language,
                                    false,
                                    true,
                                    call,
                                );
                            }
                        }),
                    );
                });
                break;
            default:
                break;
        }
        return { itemsList, hasNext };
    }

    static StdFilterObject(filter: any) {
        const strKeys = ['in', 'gt', 'gte', 'lt', 'lte'];
        const keys = Object.keys(filter ?? {});
        keys.map((k: any) => {
            if (typeof filter[k] === 'object') {
                filter[k] = this.StdFilterObject(filter[k]);
            }
            strKeys.forEach((k) => {
                if (filter[`#${k}`]) {
                    filter[`$${k}`] = filter[`#${k}`];
                    delete filter[`#${k}`];
                }
            });
        });
        return filter;
    }
}
