import { prop, index, mongoose, Severity, modelOptions } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';
import BaseModel from '../common/baseModel';

@index({ name: 'text' })
@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Collection extends BaseModel {
    @prop({ type: mongoose.Schema.Types.Mixed, required: true })
    public filter!: Record<string, JavaScriptValue>;

    @prop({ required: true })
    public modelName!: string;

    @prop({ ref: mongoose.Schema.Types.ObjectId, default: [] })
    public itemsId?: mongoose.Schema.Types.ObjectId[];

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('modelName', 'filter', 'itemsId');
        return base;
    }
}
