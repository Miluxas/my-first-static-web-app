import cron from 'node-cron';
import CollectionClass from './model';
import ProductViewClass from '../product/view';
import { getModelForClass } from '@typegoose/typegoose';
import { Aggregate } from 'mongoose';
import CommonFilterConvert from '../common/filterConvert';

const CollectionModel = getModelForClass(CollectionClass);
const ProductView = getModelForClass(ProductViewClass);

export default class CollectionCron {
    public setup() {
        // TODO : time must read form redis
        cron.schedule('*/30 * * * *', this.resetItemsId);
    }

    public async resetItemsId() {
        await CollectionModel.find({ isDeleted: false, isActive: true, modelName: 'product' }).then((list) => {
            list.map(async (collection) => {
                collection.itemsId = await CollectionCron.generateList(collection.modelName, collection.filter);
                await collection.save();
            });
        });
    }
    static async generateList(modelName: string, filter: any) {
        // eslint-disable-next-line @typescript-eslint/no-array-constructor
        const itemsId: any = [];
        filter = CollectionCron.StdFilterObject(filter ?? {});
        let aggre = new Aggregate();
        switch (modelName) {
            // case 'brand':
            //     aggre = CommonFilterConvert(
            //         filter ?? {},
            //         BrandView.aggregate([{ $match: { isDeleted: false } }]),
            //         ['title'],
            //         language,
            //     );
            //     await aggre.then(async (brands: any) => {
            //         await Promise.all(
            //             brands[0].paginatedResults.map(async (brand: any) => {
            //                 if (brand) {
            //                     itemsList.push(await BrandServer.dao(brand, false, true));
            //                 }
            //             }),
            //         );
            //     });
            //     break;
            case 'product':
                aggre = CommonFilterConvert(
                    filter ?? {},
                    ProductView.aggregate([{ $match: { isDeleted: false } }]),
                    ['name', 'description', 'Attributes.name', 'Attributes.value'],
                    'en',
                );
                await aggre.then(async (products: any) => {
                    await Promise.all(
                        products[0].paginatedResults.map(async (product: any) => {
                            if (product) {
                                itemsId.push(product._id);
                            }
                        }),
                    );
                });
                break;
            // case 'category':
            //     aggre = CommonFilterConvert(
            //         filter ?? {},
            //         CategoryView.aggregate([{ $match: { isDeleted: false } }]),
            //         ['name'],
            //         language,
            //     );
            //     await aggre.then(async (categories: any) => {
            //         await Promise.all(
            //             categories[0].paginatedResults.map(async (category: any) => {
            //                 if (category) {
            //                     itemsList.push(await CategoryServer.dao(category, false, false));
            //                 }
            //             }),
            //         );
            //     });
            //     break;
            // case 'collection':
            //     aggre = CommonFilterConvert(
            //         filter ?? {},
            //         CollectionModel.aggregate([{ $match: { isDeleted: false } }]),
            //         ['name'],
            //         language,
            //     );
            //     await aggre.then(async (collections: any) => {
            //         await Promise.all(
            //             collections[0].paginatedResults.map(async (collection: any, index: any) => {
            //                 if (collection) {
            //                     itemsList[index] = await this.dao(collection, false, true, call);
            //                 }
            //             }),
            //         );
            //     });
            //     break;
            default:
                break;
        }
        return itemsId;
    }

    static StdFilterObject(filter: any) {
        const strKeys = ['in', 'gt', 'gte', 'lt', 'lte'];
        const keys = Object.keys(filter ?? {});
        keys.map((k: any) => {
            if (typeof filter[k] === 'object') {
                filter[k] = this.StdFilterObject(filter[k]);
            }
            strKeys.forEach((k) => {
                if (filter[`#${k}`]) {
                    filter[`$${k}`] = filter[`#${k}`];
                    delete filter[`#${k}`];
                }
            });
        });
        return filter;
    }
}
