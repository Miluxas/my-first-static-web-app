import SizeGuideClass from './model';
import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import Translate from '../common/multyLang';

const SizeGuideModel = getModelForClass(SizeGuideClass);
/**
 * SizeGuide gRPC server.
 */
export default class SizeGuideServer extends BaseServer {
    protected model = SizeGuideModel;
    protected searchOn = ['type'];
    protected async dao(item: any, _isDetailed: boolean, _isList: boolean) {
        return BaseServer.objectDao(item);
    }
    protected async appDao(item: any, language: string, isDetailed: boolean, isList: boolean) {
        return SizeGuideServer.appDao(item, language, isDetailed, isList);
    }
    public static async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean) {
        let doc: any;
        const sendingData: any = [];
        for (doc of item.column) {
            sendingData.push({
                ...doc,
                title: Translate(doc.title, language, 'No title for this language'),
            });
        }
        return {
            id: item._id.toString(),
            type: item.type,
            question: Translate(item.question, language, 'No question for this language'),
            description: Translate(item.description, language, 'No description for this language'),
            columnList: sendingData,
            image: item.image ?? null,
        };
    }
}
