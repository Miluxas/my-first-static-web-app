import { prop, mongoose, modelOptions, Severity } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';
import BaseModel from '../common/baseModel';

enum TypeOfSizeGuide {
    FOOT = 'FOOT',
    TOP = 'TOP',
    DRESS = 'DRESS',
    BOTTOM = 'BOTTOM',
}

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class SizeGuide extends BaseModel {
    @prop({ type: mongoose.Schema.Types.Mixed, required: true })
    public column!: Record<string, JavaScriptValue>[];

    @prop({ enum: TypeOfSizeGuide, required: true, default: TypeOfSizeGuide.DRESS })
    public type!: TypeOfSizeGuide;

    @prop({ type: mongoose.Schema.Types.Mixed, required: true })
    public image?: Record<string, JavaScriptValue>;

    @prop({ type: String, required: true })
    public question?: Map<string, string>;

    @prop({ type: String })
    public description?: Map<string, string>;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('column', 'type', 'image', 'question', 'description');
        return base;
    }
}
