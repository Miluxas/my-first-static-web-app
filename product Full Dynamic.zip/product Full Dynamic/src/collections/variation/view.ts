export default class ViewVariation {
    public _id!: string;
}
