/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData, status } from 'grpc';
import VariationClass from './model';
import VariationViewClass from './view';
import VariationItemClass from './itemModel';
import UnmappedVariationViewClass from './unmappedView';
import { IVariation_Server } from '../../protoDef/variation_grpc_pb';
import { VariationItem } from '../../protoDef/variation_pb';

import { getModelForClass } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Types } from 'mongoose';
import { Filter, Id, List } from '../../protoDef/common_pb';
import BaseServer from '../common/baseServer';
import { Struct } from 'google-protobuf/google/protobuf/struct_pb';
import CommonFilterConvert from '../common/filterConvert';
import ToPanelList from '../common/panelListDecorator';
import Translate from '../common/multyLang';

/**
 * Create model of Variation Class.
 */
const VariationModel = getModelForClass(VariationClass);
const VariationView = getModelForClass(VariationViewClass);
/**
 * Create model of Variation Option Class.
 */
const VariationItemModel = getModelForClass(VariationItemClass);
const UnmappedVariationView = getModelForClass(UnmappedVariationViewClass);

/**
 * Variation gRPC server.
 */
export default class VariationServer extends BaseServer implements IVariation_Server {
    protected model = VariationModel;
    protected view = VariationView;
    protected async dao(variation: any, _isDetailed: boolean, _isList: boolean) {
        return {
            id: variation._id.toString(),
            createdAt: variation.createdAt?.getTime() ?? 0,
            updatedAt: variation.updatedAt?.getTime() ?? 0,
            name: variation.name ?? {},
            type: variation.type ?? 0,
            items: variation.Items.map((item: any) => ({
                id: item._id.toString(),
                name: item.name ?? {},
                values: item.values ?? [],
            })),
        };
    }
    protected async appDao(item: any, language: string, _isDetailed: boolean, _isList: boolean) {
        return {
            id: item._id.toString(),
            name: Translate(item.name, language),
            logo: item.logo,
        };
    }

    public unmappedItems(call: ServerUnaryCall<Filter>, callback: sendUnaryData<List>): void {
        try {
            CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                UnmappedVariationView.aggregate([{ $match: { isDeleted: false } }]),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ToPanelList(list, async (item) =>
                        Struct.fromJavaScript({
                            id: item._id.toString(),
                            name: item.name ?? {},
                            values: item.values ?? [],
                        }),
                    ),
                );
            });
        } catch (error) {
            console.error('!!! list ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
    /**
     * Update a variation Item from db by Id.
     * @param   id
     * @param   name
     * @param   values
     */
    public async editItem(call: ServerUnaryCall<VariationItem>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Variation Item ID structure.', name: 'WRONG Id' }, null);
                return;
            }

            const attr = await VariationItemModel.findById(call.request.getId());
            if (!attr) {
                callback({ code: 404, message: 'Variation Item Not found.', name: 'NOT found' }, null);
                return;
            }

            attr.values = call.request.getValuesList();
            try {
                attr.name = JSON.parse(call.request.getName());
            } catch (_error) {
                callback(
                    {
                        code: 400,
                        message: call.request.getName() + ' is NOT a Json string',
                        name: 'JSON ERROR',
                    },
                    null,
                );
            }
            attr.name = JSON.parse(call.request.getName());
            attr.updatedAt = new Date();
            attr.markModified('values,name');
            attr.save()
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (error) {
            console.error('!!! edit item variation in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /**
     * Add an option to variation
     * @param   id
     * @param   name
     * @param   values
     */
    public async addItem(call: ServerUnaryCall<VariationItem>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Variation ID structure.', name: 'WRONG Id' }, null);
                return;
            }

            const attr = await VariationModel.findOne({
                _id: call.request.getId(),
            });
            if (!attr) {
                callback({ code: 404, message: 'Variation Not found.', name: 'NOT found' }, null);
                return;
            }

            const newItem = new VariationItemModel();
            const option = call.request;
            if (option) {
                try {
                    newItem.name = JSON.parse(option.getName());
                } catch (_error) {
                    callback(
                        {
                            code: 400,
                            message: option.getName() + ' is NOT a Json string',
                            name: 'JSON ERROR',
                        },
                        null,
                    );
                }

                newItem.variationId = Types.ObjectId(option.getId());
                newItem.values = option.getValuesList();
                newItem
                    .save()
                    .then(() => {
                        callback(null, new Empty());
                        return;
                    })
                    .catch((err) => {
                        callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                        return;
                    });
            } else {
                callback(
                    {
                        code: 400,
                        message: 'Wrong Variation Item structure.',
                        name: 'WRONG structure',
                    },
                    null,
                );
            }
        } catch (error) {
            console.error('!!! add item variation in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /**
     * Remove an item
     * @param id
     */
    public async deleteItem(call: ServerUnaryCall<Id>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback({ code: 400, message: 'Wrong Item ID structure.', name: 'WRONG Id' }, null);
                return;
            }

            VariationItemModel.findByIdAndDelete(call.request.getId())
                .then(() => {
                    callback(null, new Empty());
                    return;
                })
                .catch((err) => {
                    callback({ code: status.UNKNOWN, message: err, name: 'Save ERROR' }, null);
                    return;
                });
        } catch (error) {
            console.error('!!! delete item variation in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }
}
