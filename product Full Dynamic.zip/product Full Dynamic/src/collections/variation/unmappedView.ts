export default class UnmappedVariation {
    public _id!: string;
}
