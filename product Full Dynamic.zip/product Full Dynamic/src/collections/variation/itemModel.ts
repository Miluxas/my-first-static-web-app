import { prop, Ref } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';
import Variation from './model';

export default class VariationItem extends BaseModel {
    @prop({ ref: Variation, required: true })
    public variationId!: Ref<Variation>;

    @prop({ type: String, required: true })
    public name!: Map<string, string>;

    @prop({ type: String })
    public values?: string[];
}
