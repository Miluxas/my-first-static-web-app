import { prop } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';

enum VariationType {
    STRING = 0,
    NUMBER = 1,
    COLOR = 2,
    SIZE = 3,
}

export default class Variation extends BaseModel {
    @prop({ type: String, required: true })
    public name!: Map<string, string>;

    @prop({ default: VariationType.STRING })
    public type?: VariationType;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('name', 'type');
        return base;
    }
}
