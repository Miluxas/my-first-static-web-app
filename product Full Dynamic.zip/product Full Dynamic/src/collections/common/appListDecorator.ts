/* eslint-disable @typescript-eslint/no-non-null-assertion */

import { AppList } from '../../protoDef/common_pb';
import { Func } from '@typegoose/typegoose/lib/types';

/* eslint-disable @typescript-eslint/no-explicit-any */
const ToAppList = async (result: any, convertor: Func, pagination: any) => {
    const tmpList = new AppList();
    await Promise.all(
        result[0].paginatedResults.map(async (item: any, index: any) => {
            if (item) {
                tmpList.getItemsList()[index] = await convertor(item);
            }
        }),
    );
    const hasNext =
        (result[0]?.totalCount[0]?.count ?? 0) > ((pagination?.page ?? 0) + 1) * (pagination?.limit ?? 1000);
    tmpList.setHasnext(hasNext);
    return tmpList;
};

export default ToAppList;
