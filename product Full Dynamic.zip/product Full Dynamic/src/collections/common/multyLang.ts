import { isMap } from 'lodash';

const Translate = (obj: any, language: string, emptyValue = '') => {
    if (isMap(obj)) {
        if (!language) return obj.get('en') ?? emptyValue;
        if (!obj) return emptyValue;
        return obj.get(language) ?? obj.get('en') ?? emptyValue;
    } else {
        if (!language) return obj['en'] ?? emptyValue;
        if (!obj) return emptyValue;
        return obj[language] ?? obj['en'] ?? emptyValue;
    }
};
export default Translate;
