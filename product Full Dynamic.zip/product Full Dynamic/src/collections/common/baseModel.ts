import { prop, mongoose, modelOptions } from '@typegoose/typegoose';
import { JavaScriptValue } from 'google-protobuf/google/protobuf/struct_pb';

@modelOptions({ schemaOptions: { timestamps: true } })
export default class BaseModel {
    public _id!: mongoose.Types.ObjectId;

    @prop({ default: false })
    public isDeleted!: boolean;

    @prop({ default: true })
    public isActive!: boolean;

    @prop({ type: mongoose.Types.ObjectId })
    public storeId?: mongoose.Types.ObjectId;

    @prop({ type: mongoose.Types.ObjectId })
    public countryId?: mongoose.Types.ObjectId;

    @prop({ type: mongoose.Types.ObjectId })
    public createdBy?: mongoose.Types.ObjectId;

    @prop({ default: new Date() })
    public createdAt?: Date;

    @prop({ default: new Date() })
    public updatedAt?: Date;

    @prop({ type: mongoose.Schema.Types.Mixed })
    public detail?: Record<string, JavaScriptValue>;

    public static getStaticFields() {
        return ['_id', 'isDeleted', 'isActived', 'storeId', 'countryId', 'createdBy'];
    }
    public static getReadOnlyFields() {
        return ['_id', 'isDeleted', 'isActived', 'createdBy'];
    }
}
