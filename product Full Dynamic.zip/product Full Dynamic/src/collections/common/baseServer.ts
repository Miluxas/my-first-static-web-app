/* eslint-disable @typescript-eslint/no-explicit-any */
import { ServerUnaryCall, sendUnaryData } from 'grpc';

import { mongoose } from '@typegoose/typegoose';
import { Empty } from 'google-protobuf/google/protobuf/empty_pb';
import { Aggregate, Types } from 'mongoose';
import { Id, Activation, List, AppList, Filter } from '../../protoDef/common_pb';
import CommonFilterConvert from './filterConvert';
import { JavaScriptValue, Struct } from 'google-protobuf/google/protobuf/struct_pb';
import ToAppList from './appListDecorator';
import ToPanelList from './panelListDecorator';
import { isArray, isBoolean, isDate, isInteger, isNumber, isObject, isString } from 'lodash';
import { BaseObject } from '../../protoDef/common_dynamic_pb';

export default abstract class BaseServer {
    protected model: any;
    protected view: any;
    protected searchOn: string[] = [];

    protected async getById(id: string, call: any): Promise<any> {
        const res = await this.customizeAggregation(call).match({ _id: mongoose.Types.ObjectId(id) });

        if (res.length == 0) return Struct.fromJavaScript({});
        return Struct.fromJavaScript(await this.dao(res[0], true, false, call));
    }

    private getNewDowWithBaseInfo(baseInfo: any) {
        const newDoc = new this.model();
        newDoc['createdBy'] = baseInfo!.getUserId();
        newDoc['storeId'] = baseInfo!.getStoreId();
        newDoc['countryId'] = baseInfo!.getCountryId();
        return newDoc;
    }

    protected afterAdd(_newDoc: any) {
        return;
    }

    public async add(call: ServerUnaryCall<BaseObject>, callback: sendUnaryData<Struct>): Promise<void> {
        try {
            /** Create new brand model with request data. */

            const newObject = call.request.getObject()!.toJavaScript();
            const keys = Object.keys(newObject);
            const newDoc = this.getNewDowWithBaseInfo(call.request.getBaseinfo());
            const staticProps = this.model.getStaticFields();
            const detail: Record<string, JavaScriptValue> = {};
            keys.forEach((key) => {
                if (staticProps.find((f) => f == key)) newDoc[key] = newObject[key];
                else detail[key] = newObject[key];
            });
            newDoc.detail = detail;
            console.log(newDoc);
            /** Save new created brand in db. */
            newDoc
                .save()
                .then(async () => {
                    await this.afterAdd(newDoc);
                    callback(null, await this.getById(newDoc.id, call));
                    return;
                })
                .catch(console.log);
        } catch (err) {
            console.error('!!! add ' + this.model.modelName + ' in Server => ', err);
            if (err.code === 11000) err = { code: 409, details: 'Duplicate code!' };
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public get(call: ServerUnaryCall<Id>, callback: sendUnaryData<Struct>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    { code: 400, message: 'Wrong ' + this.model.modelName + ' ID structure.', name: 'WRONG Id' },
                    null,
                );
                return;
            }

            this.customizeAggregation(call)
                .match({ _id: mongoose.Types.ObjectId(call.request.getId()) })
                .then(async (list: any) => {
                    if (list.length == 0) {
                        callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                        return;
                    }
                    callback(null, Struct.fromJavaScript(await this.dao(list[0], true, false, call)));
                });
        } catch (error) {
            console.error('!!! get ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public list(call: ServerUnaryCall<Filter>, callback: sendUnaryData<List>): void {
        try {
            CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                this.customizeAggregation(call),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ToPanelList(list, async (item) =>
                        Struct.fromJavaScript(await this.dao(item, true, true, call)),
                    ),
                );
            });
        } catch (error) {
            console.error('!!! list ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async edit(call: ServerUnaryCall<BaseObject>, callback: sendUnaryData<Struct>): Promise<void> {
        try {
            const newObject = call.request.getObject()!.toJavaScript();
            const keys = Object.keys(newObject);
            this.model.findById(newObject._id).then(async (findedDoc) => {
                if (!findedDoc) {
                    callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                    return;
                }

                const staticProps = this.model.getStaticFields();
                const readOnlyProps = this.model.getReadOnlyFields();
                const detail = findedDoc.detail;
                keys.forEach((key) => {
                    if (staticProps.find((f) => f == key)) {
                        if (!readOnlyProps.find((f) => f == key)) findedDoc[key] = newObject[key];
                    } else detail[key] = newObject[key];
                });
                findedDoc.detail = detail;
                findedDoc.markModified(['detail']);
                console.log(findedDoc);
                /** Save new created brand in db. */
                findedDoc
                    .save()
                    .then(async () => {
                        console.log(findedDoc);
                        callback(null, await this.getById(findedDoc.id, call));
                        return;
                    })
                    .catch(console.log);
            });
        } catch (err) {
            console.error('!!! edit ' + this.model.modelName + ' in Server => ', err);
            callback({ code: 500, message: err.message, name: '' }, null);
        }
    }

    public delete(call: ServerUnaryCall<Id>, callback: sendUnaryData<Empty>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    { code: 400, message: 'Wrong ' + this.model.modelName + ' ID structure.', name: 'WRONG Id' },
                    null,
                );
                return;
            }
            this.model.findByIdAndUpdate(call.request.getId(), { isDeleted: true }).then(async (item: any) => {
                if (!item) {
                    callback(
                        { code: 404, message: '' + this.model.modelName + ' Not found.', name: 'NOT found' },
                        null,
                    );
                    return;
                }
                callback(null, new Empty());
            });
        } catch (error) {
            console.error('!!! delete ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public async toggleActivation(call: ServerUnaryCall<Activation>, callback: sendUnaryData<Empty>): Promise<void> {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    { code: 400, message: 'Wrong ' + this.model.modelName + ' ID structure.', name: 'WRONG Id' },
                    null,
                );
                return;
            }

            await this.model
                .findByIdAndUpdate(call.request.getId(), { isActive: call.request.getIsactive() })
                .then(() => {
                    callback(null, new Empty());
                    return;
                });
        } catch (error) {
            console.error('!!! toggleActivation ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    /*****************************************************************************************************/
    public appGet(call: ServerUnaryCall<Id>, callback: sendUnaryData<Struct>): void {
        try {
            if (!Types.ObjectId.isValid(call.request.getId())) {
                callback(
                    { code: 400, message: 'Wrong ' + this.model.modelName + ' ID structure.', name: 'WRONG Id' },
                    null,
                );
                return;
            }

            this.customizeAggregation(call)
                .match({ _id: mongoose.Types.ObjectId(call.request.getId()) })
                .then(async (list: any) => {
                    if (list.length == 0) {
                        callback({ code: 404, message: this.model.modelName + ' Not found.', name: 'NOT found' }, null);
                        return;
                    }
                    callback(
                        null,
                        Struct.fromJavaScript(
                            await this.appDao(list[0], call.request.getBaseinfo()!.getLanguage(), false, false, call),
                        ),
                    );
                });
        } catch (error) {
            console.error('!!! appGet ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    public appList(call: ServerUnaryCall<Filter>, callback: sendUnaryData<AppList>): void {
        try {
            CommonFilterConvert(
                call.request.getFilter()?.toJavaScript(),
                this.customizeAggregation(call),
                this.searchOn,
                call.request.getBaseinfo()!.getLanguage(),
            ).then(async (list: any) => {
                callback(
                    null,
                    await ToAppList(
                        list,
                        async (item) =>
                            Struct.fromJavaScript(
                                await this.appDao(item, call.request.getBaseinfo()!.getLanguage(), false, true, call),
                            ),
                        call.request.getFilter()?.toJavaScript().pagination,
                    ),
                );
            });
        } catch (error) {
            console.error('!!! appList ' + this.model.modelName + ' in Server => ', error);
            callback({ code: 500, message: error.message, name: '' }, null);
        }
    }

    protected abstract dao(item: any, isDetailed: boolean, isList: boolean, call: any): Promise<any>;
    protected abstract appDao(
        item: any,
        language: string,
        isDetailed: boolean,
        isList: boolean,
        call: any,
    ): Promise<any>;

    protected customizeAggregation(_call: any): Aggregate<any> {
        return (this.view ?? this.model).aggregate([{ $match: { isDeleted: false } }]);
    }

    public static objectDao(item: any) {
        const keys = Object.keys(item);
        const checkForValidMongoDbID = new RegExp('^[0-9a-fA-F]{24}$');
        const obj = new Object();
        keys.map((k) => {
            if (checkForValidMongoDbID.test(item[k])) {
                if (k == '_id' || k == 'id') {
                    Object.assign(obj, { id: item[k].toString() });
                }
            } else if (isBoolean(item[k])) {
                Object.assign(obj, { [k]: item[k] });
            } else if (isString(item[k])) {
                Object.assign(obj, { [k]: item[k] });
            } else if (isInteger(item[k])) {
                Object.assign(obj, { [k]: item[k] });
            } else if (isNumber(item[k])) {
                Object.assign(obj, { [k]: item[k] });
            } else if (isDate(item[k])) {
                Object.assign(obj, { [k]: item[k].getTime() ?? 0 });
            } else if (isArray(item[k])) {
                Object.assign(obj, {
                    [k]: item[k].map((inItem) => BaseServer.objectDao(inItem)),
                });
            } else if (isObject(item[k])) {
                Object.assign(obj, { [k]: BaseServer.objectDao(item[k]) });
            }
        });
        return obj;
    }
}
