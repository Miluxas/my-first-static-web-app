/* eslint-disable @typescript-eslint/no-non-null-assertion */

import { List } from '../../protoDef/common_pb';
import { Func } from '@typegoose/typegoose/lib/types';

/* eslint-disable @typescript-eslint/no-explicit-any */
const ToPanelList = async (result: any, convertor: Func) => {
    const tmpList = new List();

    await Promise.all(
        await result[0].paginatedResults.map(async (item: any, index: any) => {
            if (item) {
                tmpList.getItemsList()[index] = await convertor(item);
            }
        }),
    );
    tmpList.setTotal(result[0]?.totalCount[0]?.count ?? 0);
    return tmpList;
};

export default ToPanelList;
