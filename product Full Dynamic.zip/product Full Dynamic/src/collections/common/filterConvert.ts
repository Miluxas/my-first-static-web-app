/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { isArray } from 'lodash';
import { Aggregate, isValidObjectId, Types } from 'mongoose';

/* eslint-disable @typescript-eslint/no-explicit-any */
const CommonFilterConvert = (
    filterObject: any,
    aggregate: Aggregate<any[]>,
    multiLanguageFields: string[] = [],
    language: string,
) => {
    filterObject = StdFilterObject(filterObject);
    aggregate.addFields({
        age: { $floor: { $divide: [{ $subtract: ['$$NOW', '$createdAt'] }, 24 * 60 * 60 * 1000] } },
    });
    let tmpObj = {};
    if (filterObject.filter) {
        tmpObj = filterObject.filter;
    }
    if (multiLanguageFields.length > 0 && language && filterObject.search) {
        const conditions: { [x: string]: { $regex: string; $options: string } }[] = [];
        multiLanguageFields.map((field) => {
            conditions.push({
                [field + '.' + language]: { $regex: filterObject.search?.toString() ?? '', $options: 'i' },
            });
        });
        Object.assign(tmpObj, { $or: conditions });
    }

    if (filterObject.sort && Object.keys(filterObject.sort).length > 0) {
        aggregate.sort(filterObject.sort);
    } else {
        aggregate.sort({ createdAt: -1 });
    }
    return aggregate.match(tmpObj).facet({
        paginatedResults: [
            { $skip: (filterObject.pagination?.page ?? 0) * (filterObject.pagination?.limit ?? 1000) },
            { $limit: filterObject.pagination?.limit ?? 1000 },
        ],
        totalCount: [
            {
                $count: 'count',
            },
        ],
    });
};
export default CommonFilterConvert;

const StdFilterObject = (filter: any) => {
    const regex = RegExp(/^[a-z|A-Z|0-9]+\s?At{1}$/);
    const keys = Object.keys(filter ?? {});
    const strKeys = ['in', 'gt', 'gte', 'lt', 'lte'];
    // keys.map((k: any) => {
    //     if (typeof filter[k] === 'object') {
    //         filter[k] = StdFilterObject(filter[k]);
    //     }
    //     strKeys.forEach((k) => {
    //         if (filter[`#${k}`]) {
    //             filter[`$${k}`] = filter[`#${k}`];
    //             delete filter[`#${k}`];
    //         }
    //     });
    // });
    keys.map((k: any) => {
        if (regex.test(k)) {
            filter[k] = StdDateValue(filter[k]);
        }
        if (k == 'id') {
            filter[`_id`] = filter[k];
            delete filter[k];
            k = '_id';
        }

        if (k.endsWith('.id')) {
            filter[k.replace('.id', '._id')] = filter[k];
            delete filter[k];
            k = k.replace('.id', '._id');
        }
        if (isArray(filter[k])) {
            for (let index = 0; index < filter[k].length; index++) {
                if (isValidObjectId(filter[k][index]) && typeof filter[k][index] === 'string') {
                    filter[k][index] = Types.ObjectId(filter[k][index]);
                } else filter[k][index] = StdFilterObject(filter[k][index]);
            }
        } else if (typeof filter[k] === 'object') {
            filter[k] = StdFilterObject(filter[k]);
        } else if (isValidObjectId(filter[k]) && typeof filter[k] === 'string') {
            filter[k] = Types.ObjectId(filter[k]);
        }

        strKeys.forEach((k2) => {
            if (filter[`#${k2}`]) {
                filter[`$${k2}`] = filter[`#${k2}`];
                delete filter[`#${k2}`];
            }
        });
    });
    return filter;
};

const StdDateValue = (filter: any) => {
    const keys = Object.keys(filter ?? {});
    keys.map((k: any) => {
        if (isArray(filter[k])) {
            for (let index = 0; index < filter[k].length; index++) {
                if (new Date(filter[k][index]).getTime() > 0) {
                    filter[k][index] = new Date(filter[k][index]);
                } else filter[k][index] = StdDateValue(filter[k][index]);
            }
        } else if (typeof filter[k] === 'object') {
            filter[k] = StdDateValue(filter[k]);
        } else if (new Date(filter[k]).getTime() > 0) {
            filter[k] = new Date(filter[k]);
        }
    });
    return filter;
};
