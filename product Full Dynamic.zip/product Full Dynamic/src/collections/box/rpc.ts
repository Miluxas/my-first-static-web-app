/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import BoxClass from './model';
import BoxViewClass from './view';
import { getModelForClass } from '@typegoose/typegoose';
import BaseServer from '../common/baseServer';
import CollectionServer from '../collection/rpc';
/**
 * Create model of Box Class.
 */
const BoxModel = getModelForClass(BoxClass);
const BoxView = getModelForClass(BoxViewClass);

/**
 * Box gRPC server.
 */
export default class BoxServer extends BaseServer {
    protected model = BoxModel;
    protected view = BoxView;
    protected async dao(box: any, _isDetailed: boolean, _isList: boolean, call: any) {
        return BoxServer.dao(box, call);
    }
    protected async appDao(box: any, language: string, _isDetailed: boolean, _isList: boolean, call: any) {
        return BoxServer.appDao(box, language, call);
    }

    public static async dao(box: any, call: any) {
        const itemsList = await CollectionServer.generateList(
            box.collection.modelName,
            box.collection.filter,
            call.request.getUserId(),
            'en',
            call,
        );
        return {
            id: box._id.toString(),
            collectionId: box.collectionId.toString(),
            title: box.title,
            showAllTitle: box.showAllTitle,
            items: itemsList,
            displayCount: box.displayCount ?? 0,
            modelName: box.collection.modelName ?? '',
            style: box.style ?? '',
            createdBy: box.createdBy?.toHexString() ?? '',
            storeId: box.storeId?.toHexString() ?? '',
            createdAt: box.createdAt?.getTime() ?? 0,
            updatedAt: box.updatedAt?.getTime() ?? 0,
        };
    }
    public static async appDao(box: any, language: string, call: any) {
        const itemsList = await CollectionServer.generateAppList(
            box.collection.modelName,
            box.collection.filter,
            call.request.getUserId(),
            language,
            call,
        );
        return {
            id: box._id.toString(),
            collectionId: box.collectionId.toString(),
            title: box.title[language] ?? '',
            showAllTitle: box.showAllTitle[language] ?? '',
            items: itemsList.itemsList,
            displayCount: box.displayCount ?? 0,
            modelName: box.collection.modelName ?? '',
            style: box.style ?? '',
            createdBy: box.createdBy?.toHexString() ?? '',
        };
    }
}
