import { prop, mongoose, Severity, modelOptions } from '@typegoose/typegoose';
import BaseModel from '../common/baseModel';

@modelOptions({ options: { allowMixed: Severity.ALLOW } })
export default class Box extends BaseModel {
    @prop({ type: String, required: true })
    public title!: Map<string, string>;

    @prop({ type: String, required: true })
    public showAllTitle!: Map<string, string>;

    @prop({ required: true, default: 5 })
    public displayCount!: number;

    @prop({ type: mongoose.Types.ObjectId, required: true })
    public collectionId!: mongoose.Types.ObjectId;

    @prop({ required: true })
    public style!: string;

    public static getStaticFields() {
        const base = super.getStaticFields();
        base.push('collectionId', 'style', 'displayCount', 'showAllTitle', 'title');
        return base;
    }
}
