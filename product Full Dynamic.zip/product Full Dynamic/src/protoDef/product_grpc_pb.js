// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var product_pb = require('./product_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var google_protobuf_struct_pb = require('google-protobuf/google/protobuf/struct_pb.js');
var common_pb = require('./common_pb.js');

function serialize_Activation(arg) {
  if (!(arg instanceof common_pb.Activation)) {
    throw new Error('Expected argument of type Activation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Activation(buffer_arg) {
  return common_pb.Activation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_AppList(arg) {
  if (!(arg instanceof common_pb.AppList)) {
    throw new Error('Expected argument of type AppList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_AppList(buffer_arg) {
  return common_pb.AppList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_BaseObject(arg) {
  if (!(arg instanceof common_pb.BaseObject)) {
    throw new Error('Expected argument of type BaseObject');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_BaseObject(buffer_arg) {
  return common_pb.BaseObject.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Filter(arg) {
  if (!(arg instanceof common_pb.Filter)) {
    throw new Error('Expected argument of type Filter');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Filter(buffer_arg) {
  return common_pb.Filter.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Id(arg) {
  if (!(arg instanceof common_pb.Id)) {
    throw new Error('Expected argument of type Id');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Id(buffer_arg) {
  return common_pb.Id.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_List(arg) {
  if (!(arg instanceof common_pb.List)) {
    throw new Error('Expected argument of type List');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_List(buffer_arg) {
  return common_pb.List.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Struct(arg) {
  if (!(arg instanceof google_protobuf_struct_pb.Struct)) {
    throw new Error('Expected argument of type google.protobuf.Struct');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Struct(buffer_arg) {
  return google_protobuf_struct_pb.Struct.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_AppFilterList(arg) {
  if (!(arg instanceof product_pb.AppFilterList)) {
    throw new Error('Expected argument of type product.AppFilterList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_AppFilterList(buffer_arg) {
  return product_pb.AppFilterList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_ProductAndCategoryId(arg) {
  if (!(arg instanceof product_pb.ProductAndCategoryId)) {
    throw new Error('Expected argument of type product.ProductAndCategoryId');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_ProductAndCategoryId(buffer_arg) {
  return product_pb.ProductAndCategoryId.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_ProductAttributeItemIds(arg) {
  if (!(arg instanceof product_pb.ProductAttributeItemIds)) {
    throw new Error('Expected argument of type product.ProductAttributeItemIds');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_ProductAttributeItemIds(buffer_arg) {
  return product_pb.ProductAttributeItemIds.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_ProductSkuId(arg) {
  if (!(arg instanceof product_pb.ProductSkuId)) {
    throw new Error('Expected argument of type product.ProductSkuId');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_ProductSkuId(buffer_arg) {
  return product_pb.ProductSkuId.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_SkuGenerate(arg) {
  if (!(arg instanceof product_pb.SkuGenerate)) {
    throw new Error('Expected argument of type product.SkuGenerate');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_SkuGenerate(buffer_arg) {
  return product_pb.SkuGenerate.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// Product Service
var Product_Service = exports.Product_Service = {
  add: {
    path: '/product.Product_/add',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  get: {
    path: '/product.Product_/get',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  list: {
    path: '/product.Product_/list',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.List,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_List,
    responseDeserialize: deserialize_List,
  },
  edit: {
    path: '/product.Product_/edit',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  delete: {
    path: '/product.Product_/delete',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  toggleActivation: {
    path: '/product.Product_/toggleActivation',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Activation,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Activation,
    requestDeserialize: deserialize_Activation,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  appList: {
    path: '/product.Product_/appList',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.AppList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_AppList,
    responseDeserialize: deserialize_AppList,
  },
  appGet: {
    path: '/product.Product_/appGet',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  appFilter: {
    path: '/product.Product_/appFilter',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: product_pb.AppFilterList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_product_AppFilterList,
    responseDeserialize: deserialize_product_AppFilterList,
  },
  addToCategory: {
    path: '/product.Product_/addToCategory',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.ProductAndCategoryId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_ProductAndCategoryId,
    requestDeserialize: deserialize_product_ProductAndCategoryId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  deleteFromCategory: {
    path: '/product.Product_/deleteFromCategory',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.ProductAndCategoryId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_ProductAndCategoryId,
    requestDeserialize: deserialize_product_ProductAndCategoryId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  addAttribute: {
    path: '/product.Product_/addAttribute',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.ProductAttributeItemIds,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_ProductAttributeItemIds,
    requestDeserialize: deserialize_product_ProductAttributeItemIds,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  deleteAttribute: {
    path: '/product.Product_/deleteAttribute',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.ProductAttributeItemIds,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_ProductAttributeItemIds,
    requestDeserialize: deserialize_product_ProductAttributeItemIds,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  setDefaultSku: {
    path: '/product.Product_/setDefaultSku',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.ProductSkuId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_ProductSkuId,
    requestDeserialize: deserialize_product_ProductSkuId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  generateSku: {
    path: '/product.Product_/generateSku',
    requestStream: false,
    responseStream: false,
    requestType: product_pb.SkuGenerate,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_SkuGenerate,
    requestDeserialize: deserialize_product_SkuGenerate,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
};

exports.Product_Client = grpc.makeGenericClientConstructor(Product_Service);
