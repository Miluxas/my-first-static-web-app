// package: product
// file: page.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class BoxOrder extends jspb.Message { 
    getId(): string;
    setId(value: string): BoxOrder;

    getBoxId(): string;
    setBoxId(value: string): BoxOrder;

    getOrder(): number;
    setOrder(value: number): BoxOrder;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): BoxOrder;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): BoxOrder.AsObject;
    static toObject(includeInstance: boolean, msg: BoxOrder): BoxOrder.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: BoxOrder, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): BoxOrder;
    static deserializeBinaryFromReader(message: BoxOrder, reader: jspb.BinaryReader): BoxOrder;
}

export namespace BoxOrder {
    export type AsObject = {
        id: string,
        boxId: string,
        order: number,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class ByName extends jspb.Message { 
    getName(): string;
    setName(value: string): ByName;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): ByName;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ByName.AsObject;
    static toObject(includeInstance: boolean, msg: ByName): ByName.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ByName, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ByName;
    static deserializeBinaryFromReader(message: ByName, reader: jspb.BinaryReader): ByName;
}

export namespace ByName {
    export type AsObject = {
        name: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
