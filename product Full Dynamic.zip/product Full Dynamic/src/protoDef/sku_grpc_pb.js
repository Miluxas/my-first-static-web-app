// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var sku_pb = require('./sku_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var google_protobuf_struct_pb = require('google-protobuf/google/protobuf/struct_pb.js');
var common_pb = require('./common_pb.js');

function serialize_Activation(arg) {
  if (!(arg instanceof common_pb.Activation)) {
    throw new Error('Expected argument of type Activation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Activation(buffer_arg) {
  return common_pb.Activation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_AppList(arg) {
  if (!(arg instanceof common_pb.AppList)) {
    throw new Error('Expected argument of type AppList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_AppList(buffer_arg) {
  return common_pb.AppList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_BaseObject(arg) {
  if (!(arg instanceof common_pb.BaseObject)) {
    throw new Error('Expected argument of type BaseObject');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_BaseObject(buffer_arg) {
  return common_pb.BaseObject.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Filter(arg) {
  if (!(arg instanceof common_pb.Filter)) {
    throw new Error('Expected argument of type Filter');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Filter(buffer_arg) {
  return common_pb.Filter.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Id(arg) {
  if (!(arg instanceof common_pb.Id)) {
    throw new Error('Expected argument of type Id');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Id(buffer_arg) {
  return common_pb.Id.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_List(arg) {
  if (!(arg instanceof common_pb.List)) {
    throw new Error('Expected argument of type List');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_List(buffer_arg) {
  return common_pb.List.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Struct(arg) {
  if (!(arg instanceof google_protobuf_struct_pb.Struct)) {
    throw new Error('Expected argument of type google.protobuf.Struct');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Struct(buffer_arg) {
  return google_protobuf_struct_pb.Struct.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_SkuImage(arg) {
  if (!(arg instanceof sku_pb.SkuImage)) {
    throw new Error('Expected argument of type product.SkuImage');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_SkuImage(buffer_arg) {
  return sku_pb.SkuImage.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// Sku Service
var Sku_Service = exports.Sku_Service = {
  add: {
    path: '/product.Sku_/add',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  get: {
    path: '/product.Sku_/get',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  list: {
    path: '/product.Sku_/list',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.List,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_List,
    responseDeserialize: deserialize_List,
  },
  edit: {
    path: '/product.Sku_/edit',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  delete: {
    path: '/product.Sku_/delete',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  toggleActivation: {
    path: '/product.Sku_/toggleActivation',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Activation,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Activation,
    requestDeserialize: deserialize_Activation,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  appGet: {
    path: '/product.Sku_/appGet',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  appList: {
    path: '/product.Sku_/appList',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.AppList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_AppList,
    responseDeserialize: deserialize_AppList,
  },
  addImage: {
    path: '/product.Sku_/addImage',
    requestStream: false,
    responseStream: false,
    requestType: sku_pb.SkuImage,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_SkuImage,
    requestDeserialize: deserialize_product_SkuImage,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  deleteImage: {
    path: '/product.Sku_/deleteImage',
    requestStream: false,
    responseStream: false,
    requestType: sku_pb.SkuImage,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_SkuImage,
    requestDeserialize: deserialize_product_SkuImage,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
};

exports.Sku_Client = grpc.makeGenericClientConstructor(Sku_Service);
