// package: product
// file: category.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as category_pb from "./category_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

interface ICategory_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    add: ICategory_Service_Iadd;
    get: ICategory_Service_Iget;
    getTree: ICategory_Service_IgetTree;
    list: ICategory_Service_Ilist;
    edit: ICategory_Service_Iedit;
    delete: ICategory_Service_Idelete;
    toggleActivation: ICategory_Service_ItoggleActivation;
    appGet: ICategory_Service_IappGet;
    appList: ICategory_Service_IappList;
    setParent: ICategory_Service_IsetParent;
    setOrder: ICategory_Service_IsetOrder;
    deleteParent: ICategory_Service_IdeleteParent;
    addAttribute: ICategory_Service_IaddAttribute;
    deleteAttribute: ICategory_Service_IdeleteAttribute;
    getAttributes: ICategory_Service_IgetAttributes;
}

interface ICategory_Service_Iadd extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Category_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICategory_Service_Iget extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Category_/get";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICategory_Service_IgetTree extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Category_/getTree";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICategory_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Category_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}
interface ICategory_Service_Iedit extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Category_/edit";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICategory_Service_Idelete extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/delete";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_ItoggleActivation extends grpc.MethodDefinition<common_pb.Activation, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/toggleActivation";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Activation>;
    requestDeserialize: grpc.deserialize<common_pb.Activation>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IappGet extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Category_/appGet";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICategory_Service_IappList extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Category_/appList";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}
interface ICategory_Service_IsetParent extends grpc.MethodDefinition<category_pb.CategoryAndParentId, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/setParent";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<category_pb.CategoryAndParentId>;
    requestDeserialize: grpc.deserialize<category_pb.CategoryAndParentId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IsetOrder extends grpc.MethodDefinition<category_pb.CategoryOrder, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/setOrder";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<category_pb.CategoryOrder>;
    requestDeserialize: grpc.deserialize<category_pb.CategoryOrder>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IdeleteParent extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/deleteParent";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IaddAttribute extends grpc.MethodDefinition<category_pb.CategoryAttributes, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/addAttribute";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<category_pb.CategoryAttributes>;
    requestDeserialize: grpc.deserialize<category_pb.CategoryAttributes>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IdeleteAttribute extends grpc.MethodDefinition<category_pb.CategoryAttributes, google_protobuf_empty_pb.Empty> {
    path: "/product.Category_/deleteAttribute";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<category_pb.CategoryAttributes>;
    requestDeserialize: grpc.deserialize<category_pb.CategoryAttributes>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICategory_Service_IgetAttributes extends grpc.MethodDefinition<common_pb.Ids, category_pb.Attributes> {
    path: "/product.Category_/getAttributes";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Ids>;
    requestDeserialize: grpc.deserialize<common_pb.Ids>;
    responseSerialize: grpc.serialize<category_pb.Attributes>;
    responseDeserialize: grpc.deserialize<category_pb.Attributes>;
}

export const Category_Service: ICategory_Service;

export interface ICategory_Server {
    add: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    get: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    getTree: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
    edit: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    delete: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    toggleActivation: grpc.handleUnaryCall<common_pb.Activation, google_protobuf_empty_pb.Empty>;
    appGet: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    appList: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
    setParent: grpc.handleUnaryCall<category_pb.CategoryAndParentId, google_protobuf_empty_pb.Empty>;
    setOrder: grpc.handleUnaryCall<category_pb.CategoryOrder, google_protobuf_empty_pb.Empty>;
    deleteParent: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    addAttribute: grpc.handleUnaryCall<category_pb.CategoryAttributes, google_protobuf_empty_pb.Empty>;
    deleteAttribute: grpc.handleUnaryCall<category_pb.CategoryAttributes, google_protobuf_empty_pb.Empty>;
    getAttributes: grpc.handleUnaryCall<common_pb.Ids, category_pb.Attributes>;
}

export interface ICategory_Client {
    add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getTree(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getTree(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getTree(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    setParent(request: category_pb.CategoryAndParentId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setParent(request: category_pb.CategoryAndParentId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setParent(request: category_pb.CategoryAndParentId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setOrder(request: category_pb.CategoryOrder, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setOrder(request: category_pb.CategoryOrder, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setOrder(request: category_pb.CategoryOrder, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteParent(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteParent(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteParent(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: category_pb.CategoryAttributes, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: category_pb.CategoryAttributes, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    getAttributes(request: common_pb.Ids, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
    getAttributes(request: common_pb.Ids, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
    getAttributes(request: common_pb.Ids, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
}

export class Category_Client extends grpc.Client implements ICategory_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getTree(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getTree(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getTree(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public setParent(request: category_pb.CategoryAndParentId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setParent(request: category_pb.CategoryAndParentId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setParent(request: category_pb.CategoryAndParentId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setOrder(request: category_pb.CategoryOrder, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setOrder(request: category_pb.CategoryOrder, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setOrder(request: category_pb.CategoryOrder, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteParent(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteParent(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteParent(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: category_pb.CategoryAttributes, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: category_pb.CategoryAttributes, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: category_pb.CategoryAttributes, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public getAttributes(request: common_pb.Ids, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
    public getAttributes(request: common_pb.Ids, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
    public getAttributes(request: common_pb.Ids, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: category_pb.Attributes) => void): grpc.ClientUnaryCall;
}
