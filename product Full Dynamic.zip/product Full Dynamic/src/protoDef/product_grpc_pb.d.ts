// package: product
// file: product.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as product_pb from "./product_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

interface IProduct_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    add: IProduct_Service_Iadd;
    get: IProduct_Service_Iget;
    list: IProduct_Service_Ilist;
    edit: IProduct_Service_Iedit;
    delete: IProduct_Service_Idelete;
    toggleActivation: IProduct_Service_ItoggleActivation;
    appList: IProduct_Service_IappList;
    appGet: IProduct_Service_IappGet;
    appFilter: IProduct_Service_IappFilter;
    addToCategory: IProduct_Service_IaddToCategory;
    deleteFromCategory: IProduct_Service_IdeleteFromCategory;
    addAttribute: IProduct_Service_IaddAttribute;
    deleteAttribute: IProduct_Service_IdeleteAttribute;
    setDefaultSku: IProduct_Service_IsetDefaultSku;
    generateSku: IProduct_Service_IgenerateSku;
}

interface IProduct_Service_Iadd extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Product_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IProduct_Service_Iget extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Product_/get";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IProduct_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Product_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}
interface IProduct_Service_Iedit extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Product_/edit";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IProduct_Service_Idelete extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/delete";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_ItoggleActivation extends grpc.MethodDefinition<common_pb.Activation, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/toggleActivation";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Activation>;
    requestDeserialize: grpc.deserialize<common_pb.Activation>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IappList extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Product_/appList";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}
interface IProduct_Service_IappGet extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Product_/appGet";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IProduct_Service_IappFilter extends grpc.MethodDefinition<common_pb.Filter, product_pb.AppFilterList> {
    path: "/product.Product_/appFilter";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<product_pb.AppFilterList>;
    responseDeserialize: grpc.deserialize<product_pb.AppFilterList>;
}
interface IProduct_Service_IaddToCategory extends grpc.MethodDefinition<product_pb.ProductAndCategoryId, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/addToCategory";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.ProductAndCategoryId>;
    requestDeserialize: grpc.deserialize<product_pb.ProductAndCategoryId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IdeleteFromCategory extends grpc.MethodDefinition<product_pb.ProductAndCategoryId, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/deleteFromCategory";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.ProductAndCategoryId>;
    requestDeserialize: grpc.deserialize<product_pb.ProductAndCategoryId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IaddAttribute extends grpc.MethodDefinition<product_pb.ProductAttributeItemIds, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/addAttribute";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.ProductAttributeItemIds>;
    requestDeserialize: grpc.deserialize<product_pb.ProductAttributeItemIds>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IdeleteAttribute extends grpc.MethodDefinition<product_pb.ProductAttributeItemIds, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/deleteAttribute";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.ProductAttributeItemIds>;
    requestDeserialize: grpc.deserialize<product_pb.ProductAttributeItemIds>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IsetDefaultSku extends grpc.MethodDefinition<product_pb.ProductSkuId, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/setDefaultSku";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.ProductSkuId>;
    requestDeserialize: grpc.deserialize<product_pb.ProductSkuId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IProduct_Service_IgenerateSku extends grpc.MethodDefinition<product_pb.SkuGenerate, google_protobuf_empty_pb.Empty> {
    path: "/product.Product_/generateSku";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<product_pb.SkuGenerate>;
    requestDeserialize: grpc.deserialize<product_pb.SkuGenerate>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}

export const Product_Service: IProduct_Service;

export interface IProduct_Server {
    add: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    get: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
    edit: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    delete: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    toggleActivation: grpc.handleUnaryCall<common_pb.Activation, google_protobuf_empty_pb.Empty>;
    appList: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
    appGet: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    appFilter: grpc.handleUnaryCall<common_pb.Filter, product_pb.AppFilterList>;
    addToCategory: grpc.handleUnaryCall<product_pb.ProductAndCategoryId, google_protobuf_empty_pb.Empty>;
    deleteFromCategory: grpc.handleUnaryCall<product_pb.ProductAndCategoryId, google_protobuf_empty_pb.Empty>;
    addAttribute: grpc.handleUnaryCall<product_pb.ProductAttributeItemIds, google_protobuf_empty_pb.Empty>;
    deleteAttribute: grpc.handleUnaryCall<product_pb.ProductAttributeItemIds, google_protobuf_empty_pb.Empty>;
    setDefaultSku: grpc.handleUnaryCall<product_pb.ProductSkuId, google_protobuf_empty_pb.Empty>;
    generateSku: grpc.handleUnaryCall<product_pb.SkuGenerate, google_protobuf_empty_pb.Empty>;
}

export interface IProduct_Client {
    add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appFilter(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    appFilter(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    appFilter(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    addToCategory(request: product_pb.ProductAndCategoryId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addToCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addToCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteFromCategory(request: product_pb.ProductAndCategoryId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteFromCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteFromCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: product_pb.ProductAttributeItemIds, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    addAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: product_pb.ProductAttributeItemIds, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setDefaultSku(request: product_pb.ProductSkuId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setDefaultSku(request: product_pb.ProductSkuId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setDefaultSku(request: product_pb.ProductSkuId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    generateSku(request: product_pb.SkuGenerate, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    generateSku(request: product_pb.SkuGenerate, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    generateSku(request: product_pb.SkuGenerate, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
}

export class Product_Client extends grpc.Client implements IProduct_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appFilter(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    public appFilter(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    public appFilter(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: product_pb.AppFilterList) => void): grpc.ClientUnaryCall;
    public addToCategory(request: product_pb.ProductAndCategoryId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addToCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addToCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteFromCategory(request: product_pb.ProductAndCategoryId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteFromCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteFromCategory(request: product_pb.ProductAndCategoryId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: product_pb.ProductAttributeItemIds, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public addAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: product_pb.ProductAttributeItemIds, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteAttribute(request: product_pb.ProductAttributeItemIds, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setDefaultSku(request: product_pb.ProductSkuId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setDefaultSku(request: product_pb.ProductSkuId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setDefaultSku(request: product_pb.ProductSkuId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public generateSku(request: product_pb.SkuGenerate, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public generateSku(request: product_pb.SkuGenerate, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public generateSku(request: product_pb.SkuGenerate, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
}
