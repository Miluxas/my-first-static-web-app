// package: product
// file: sku.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class SkuVariation extends jspb.Message { 
    getId(): string;
    setId(value: string): SkuVariation;


    hasVariation(): boolean;
    clearVariation(): void;
    getVariation(): SVariation | undefined;
    setVariation(value?: SVariation): SkuVariation;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): SkuVariation;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SkuVariation.AsObject;
    static toObject(includeInstance: boolean, msg: SkuVariation): SkuVariation.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SkuVariation, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SkuVariation;
    static deserializeBinaryFromReader(message: SkuVariation, reader: jspb.BinaryReader): SkuVariation;
}

export namespace SkuVariation {
    export type AsObject = {
        id: string,
        variation?: SVariation.AsObject,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class SVariation extends jspb.Message { 
    getVariationId(): string;
    setVariationId(value: string): SVariation;

    getVariationItemId(): string;
    setVariationItemId(value: string): SVariation;

    getVariationName(): string;
    setVariationName(value: string): SVariation;

    getVariationItemName(): string;
    setVariationItemName(value: string): SVariation;

    getVariationItemValue(): string;
    setVariationItemValue(value: string): SVariation;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SVariation.AsObject;
    static toObject(includeInstance: boolean, msg: SVariation): SVariation.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SVariation, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SVariation;
    static deserializeBinaryFromReader(message: SVariation, reader: jspb.BinaryReader): SVariation;
}

export namespace SVariation {
    export type AsObject = {
        variationId: string,
        variationItemId: string,
        variationName: string,
        variationItemName: string,
        variationItemValue: string,
    }
}

export class SkuImage extends jspb.Message { 
    getId(): string;
    setId(value: string): SkuImage;


    hasImage(): boolean;
    clearImage(): void;
    getImage(): google_protobuf_struct_pb.Struct | undefined;
    setImage(value?: google_protobuf_struct_pb.Struct): SkuImage;

    getOrder(): number;
    setOrder(value: number): SkuImage;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): SkuImage;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SkuImage.AsObject;
    static toObject(includeInstance: boolean, msg: SkuImage): SkuImage.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SkuImage, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SkuImage;
    static deserializeBinaryFromReader(message: SkuImage, reader: jspb.BinaryReader): SkuImage;
}

export namespace SkuImage {
    export type AsObject = {
        id: string,
        image?: google_protobuf_struct_pb.Struct.AsObject,
        order: number,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
