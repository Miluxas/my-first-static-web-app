// package: product
// file: favorite.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as common_pb from "./common_pb";

export class OwnerId extends jspb.Message { 
    getProductId(): string;
    setProductId(value: string): OwnerId;

    getUserId(): string;
    setUserId(value: string): OwnerId;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): OwnerId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): OwnerId.AsObject;
    static toObject(includeInstance: boolean, msg: OwnerId): OwnerId.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: OwnerId, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): OwnerId;
    static deserializeBinaryFromReader(message: OwnerId, reader: jspb.BinaryReader): OwnerId;
}

export namespace OwnerId {
    export type AsObject = {
        productId: string,
        userId: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
