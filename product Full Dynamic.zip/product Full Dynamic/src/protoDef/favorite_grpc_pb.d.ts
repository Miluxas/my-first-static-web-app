// package: product
// file: favorite.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as favorite_pb from "./favorite_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as common_pb from "./common_pb";

interface IFavorite_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    remove: IFavorite_Service_Iremove;
    add: IFavorite_Service_Iadd;
    list: IFavorite_Service_Ilist;
}

interface IFavorite_Service_Iremove extends grpc.MethodDefinition<favorite_pb.OwnerId, google_protobuf_empty_pb.Empty> {
    path: "/product.Favorite_/remove";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<favorite_pb.OwnerId>;
    requestDeserialize: grpc.deserialize<favorite_pb.OwnerId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IFavorite_Service_Iadd extends grpc.MethodDefinition<favorite_pb.OwnerId, google_protobuf_empty_pb.Empty> {
    path: "/product.Favorite_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<favorite_pb.OwnerId>;
    requestDeserialize: grpc.deserialize<favorite_pb.OwnerId>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IFavorite_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Favorite_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}

export const Favorite_Service: IFavorite_Service;

export interface IFavorite_Server {
    remove: grpc.handleUnaryCall<favorite_pb.OwnerId, google_protobuf_empty_pb.Empty>;
    add: grpc.handleUnaryCall<favorite_pb.OwnerId, google_protobuf_empty_pb.Empty>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
}

export interface IFavorite_Client {
    remove(request: favorite_pb.OwnerId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    remove(request: favorite_pb.OwnerId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    remove(request: favorite_pb.OwnerId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    add(request: favorite_pb.OwnerId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    add(request: favorite_pb.OwnerId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    add(request: favorite_pb.OwnerId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
}

export class Favorite_Client extends grpc.Client implements IFavorite_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public remove(request: favorite_pb.OwnerId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public remove(request: favorite_pb.OwnerId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public remove(request: favorite_pb.OwnerId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public add(request: favorite_pb.OwnerId, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public add(request: favorite_pb.OwnerId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public add(request: favorite_pb.OwnerId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
}
