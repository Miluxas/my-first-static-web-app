// package: product
// file: attribute.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as attribute_pb from "./attribute_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

interface IAttribute_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    add: IAttribute_Service_Iadd;
    get: IAttribute_Service_Iget;
    list: IAttribute_Service_Ilist;
    edit: IAttribute_Service_Iedit;
    delete: IAttribute_Service_Idelete;
    toggleActivation: IAttribute_Service_ItoggleActivation;
    appList: IAttribute_Service_IappList;
    appGet: IAttribute_Service_IappGet;
    addItem: IAttribute_Service_IaddItem;
    deleteItem: IAttribute_Service_IdeleteItem;
    editItem: IAttribute_Service_IeditItem;
    unmappedItems: IAttribute_Service_IunmappedItems;
}

interface IAttribute_Service_Iadd extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_Iget extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/get";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Attribute_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}
interface IAttribute_Service_Iedit extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/edit";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_Idelete extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Attribute_/delete";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IAttribute_Service_ItoggleActivation extends grpc.MethodDefinition<common_pb.Activation, google_protobuf_empty_pb.Empty> {
    path: "/product.Attribute_/toggleActivation";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Activation>;
    requestDeserialize: grpc.deserialize<common_pb.Activation>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IAttribute_Service_IappList extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Attribute_/appList";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}
interface IAttribute_Service_IappGet extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/appGet";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_IaddItem extends grpc.MethodDefinition<attribute_pb.AttributeItem, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/addItem";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<attribute_pb.AttributeItem>;
    requestDeserialize: grpc.deserialize<attribute_pb.AttributeItem>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_IdeleteItem extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Attribute_/deleteItem";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IAttribute_Service_IeditItem extends grpc.MethodDefinition<attribute_pb.AttributeItem, google_protobuf_struct_pb.Struct> {
    path: "/product.Attribute_/editItem";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<attribute_pb.AttributeItem>;
    requestDeserialize: grpc.deserialize<attribute_pb.AttributeItem>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IAttribute_Service_IunmappedItems extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Attribute_/unmappedItems";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}

export const Attribute_Service: IAttribute_Service;

export interface IAttribute_Server {
    add: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    get: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
    edit: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    delete: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    toggleActivation: grpc.handleUnaryCall<common_pb.Activation, google_protobuf_empty_pb.Empty>;
    appList: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
    appGet: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    addItem: grpc.handleUnaryCall<attribute_pb.AttributeItem, google_protobuf_struct_pb.Struct>;
    deleteItem: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    editItem: grpc.handleUnaryCall<attribute_pb.AttributeItem, google_protobuf_struct_pb.Struct>;
    unmappedItems: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
}

export interface IAttribute_Client {
    add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    addItem(request: attribute_pb.AttributeItem, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    addItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    addItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    deleteItem(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteItem(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    deleteItem(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    editItem(request: attribute_pb.AttributeItem, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    editItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    editItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    unmappedItems(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    unmappedItems(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    unmappedItems(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
}

export class Attribute_Client extends grpc.Client implements IAttribute_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public addItem(request: attribute_pb.AttributeItem, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public addItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public addItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public deleteItem(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteItem(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public deleteItem(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public editItem(request: attribute_pb.AttributeItem, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public editItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public editItem(request: attribute_pb.AttributeItem, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public unmappedItems(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public unmappedItems(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public unmappedItems(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
}
