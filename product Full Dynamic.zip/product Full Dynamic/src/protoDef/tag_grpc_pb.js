// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var google_protobuf_struct_pb = require('google-protobuf/google/protobuf/struct_pb.js');
var common_pb = require('./common_pb.js');

function serialize_Activation(arg) {
  if (!(arg instanceof common_pb.Activation)) {
    throw new Error('Expected argument of type Activation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Activation(buffer_arg) {
  return common_pb.Activation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_AppList(arg) {
  if (!(arg instanceof common_pb.AppList)) {
    throw new Error('Expected argument of type AppList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_AppList(buffer_arg) {
  return common_pb.AppList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_BaseObject(arg) {
  if (!(arg instanceof common_pb.BaseObject)) {
    throw new Error('Expected argument of type BaseObject');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_BaseObject(buffer_arg) {
  return common_pb.BaseObject.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Filter(arg) {
  if (!(arg instanceof common_pb.Filter)) {
    throw new Error('Expected argument of type Filter');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Filter(buffer_arg) {
  return common_pb.Filter.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Id(arg) {
  if (!(arg instanceof common_pb.Id)) {
    throw new Error('Expected argument of type Id');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Id(buffer_arg) {
  return common_pb.Id.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_List(arg) {
  if (!(arg instanceof common_pb.List)) {
    throw new Error('Expected argument of type List');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_List(buffer_arg) {
  return common_pb.List.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Struct(arg) {
  if (!(arg instanceof google_protobuf_struct_pb.Struct)) {
    throw new Error('Expected argument of type google.protobuf.Struct');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Struct(buffer_arg) {
  return google_protobuf_struct_pb.Struct.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// Tag Service
var Tag_Service = exports.Tag_Service = {
  add: {
    path: '/product.Tag_/add',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  get: {
    path: '/product.Tag_/get',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  list: {
    path: '/product.Tag_/list',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.List,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_List,
    responseDeserialize: deserialize_List,
  },
  edit: {
    path: '/product.Tag_/edit',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  delete: {
    path: '/product.Tag_/delete',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  toggleActivation: {
    path: '/product.Tag_/toggleActivation',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Activation,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Activation,
    requestDeserialize: deserialize_Activation,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  appGet: {
    path: '/product.Tag_/appGet',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  appList: {
    path: '/product.Tag_/appList',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.AppList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_AppList,
    responseDeserialize: deserialize_AppList,
  },
};

exports.Tag_Client = grpc.makeGenericClientConstructor(Tag_Service);
