// package: 
// file: common.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";

export class BaseInfo extends jspb.Message { 
    getLanguage(): string;
    setLanguage(value: string): BaseInfo;

    getUserId(): string;
    setUserId(value: string): BaseInfo;

    getStoreId(): string;
    setStoreId(value: string): BaseInfo;

    getCountryId(): string;
    setCountryId(value: string): BaseInfo;

    getCurrencyRate(): number;
    setCurrencyRate(value: number): BaseInfo;

    getCurrencySymbol(): string;
    setCurrencySymbol(value: string): BaseInfo;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): BaseInfo.AsObject;
    static toObject(includeInstance: boolean, msg: BaseInfo): BaseInfo.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: BaseInfo, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): BaseInfo;
    static deserializeBinaryFromReader(message: BaseInfo, reader: jspb.BinaryReader): BaseInfo;
}

export namespace BaseInfo {
    export type AsObject = {
        language: string,
        userId: string,
        storeId: string,
        countryId: string,
        currencyRate: number,
        currencySymbol: string,
    }
}

export class BaseObject extends jspb.Message { 

    hasObject(): boolean;
    clearObject(): void;
    getObject(): google_protobuf_struct_pb.Struct | undefined;
    setObject(value?: google_protobuf_struct_pb.Struct): BaseObject;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): BaseObject;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): BaseObject.AsObject;
    static toObject(includeInstance: boolean, msg: BaseObject): BaseObject.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: BaseObject, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): BaseObject;
    static deserializeBinaryFromReader(message: BaseObject, reader: jspb.BinaryReader): BaseObject;
}

export namespace BaseObject {
    export type AsObject = {
        object?: google_protobuf_struct_pb.Struct.AsObject,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class Filter extends jspb.Message { 

    hasFilter(): boolean;
    clearFilter(): void;
    getFilter(): google_protobuf_struct_pb.Struct | undefined;
    setFilter(value?: google_protobuf_struct_pb.Struct): Filter;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): Filter;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Filter.AsObject;
    static toObject(includeInstance: boolean, msg: Filter): Filter.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Filter, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Filter;
    static deserializeBinaryFromReader(message: Filter, reader: jspb.BinaryReader): Filter;
}

export namespace Filter {
    export type AsObject = {
        filter?: google_protobuf_struct_pb.Struct.AsObject,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class Id extends jspb.Message { 
    getId(): string;
    setId(value: string): Id;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): Id;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Id.AsObject;
    static toObject(includeInstance: boolean, msg: Id): Id.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Id, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Id;
    static deserializeBinaryFromReader(message: Id, reader: jspb.BinaryReader): Id;
}

export namespace Id {
    export type AsObject = {
        id: string,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class Ids extends jspb.Message { 
    clearIdList(): void;
    getIdList(): Array<string>;
    setIdList(value: Array<string>): Ids;
    addId(value: string, index?: number): string;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): Ids;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Ids.AsObject;
    static toObject(includeInstance: boolean, msg: Ids): Ids.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Ids, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Ids;
    static deserializeBinaryFromReader(message: Ids, reader: jspb.BinaryReader): Ids;
}

export namespace Ids {
    export type AsObject = {
        idList: Array<string>,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class AppList extends jspb.Message { 
    clearItemsList(): void;
    getItemsList(): Array<google_protobuf_struct_pb.Struct>;
    setItemsList(value: Array<google_protobuf_struct_pb.Struct>): AppList;
    addItems(value?: google_protobuf_struct_pb.Struct, index?: number): google_protobuf_struct_pb.Struct;

    getHasnext(): boolean;
    setHasnext(value: boolean): AppList;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): AppList;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AppList.AsObject;
    static toObject(includeInstance: boolean, msg: AppList): AppList.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: AppList, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AppList;
    static deserializeBinaryFromReader(message: AppList, reader: jspb.BinaryReader): AppList;
}

export namespace AppList {
    export type AsObject = {
        itemsList: Array<google_protobuf_struct_pb.Struct.AsObject>,
        hasnext: boolean,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class List extends jspb.Message { 
    clearItemsList(): void;
    getItemsList(): Array<google_protobuf_struct_pb.Struct>;
    setItemsList(value: Array<google_protobuf_struct_pb.Struct>): List;
    addItems(value?: google_protobuf_struct_pb.Struct, index?: number): google_protobuf_struct_pb.Struct;

    getTotal(): number;
    setTotal(value: number): List;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): List;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): List.AsObject;
    static toObject(includeInstance: boolean, msg: List): List.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: List, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): List;
    static deserializeBinaryFromReader(message: List, reader: jspb.BinaryReader): List;
}

export namespace List {
    export type AsObject = {
        itemsList: Array<google_protobuf_struct_pb.Struct.AsObject>,
        total: number,
        baseinfo?: BaseInfo.AsObject,
    }
}

export class Activation extends jspb.Message { 
    getId(): string;
    setId(value: string): Activation;

    getIsactive(): boolean;
    setIsactive(value: boolean): Activation;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): BaseInfo | undefined;
    setBaseinfo(value?: BaseInfo): Activation;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Activation.AsObject;
    static toObject(includeInstance: boolean, msg: Activation): Activation.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Activation, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Activation;
    static deserializeBinaryFromReader(message: Activation, reader: jspb.BinaryReader): Activation;
}

export namespace Activation {
    export type AsObject = {
        id: string,
        isactive: boolean,
        baseinfo?: BaseInfo.AsObject,
    }
}
