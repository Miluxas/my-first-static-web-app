// package: product
// file: variation.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class VariationItem extends jspb.Message { 
    getId(): string;
    setId(value: string): VariationItem;

    getName(): string;
    setName(value: string): VariationItem;

    clearValuesList(): void;
    getValuesList(): Array<string>;
    setValuesList(value: Array<string>): VariationItem;
    addValues(value: string, index?: number): string;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): VariationItem;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): VariationItem.AsObject;
    static toObject(includeInstance: boolean, msg: VariationItem): VariationItem.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: VariationItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): VariationItem;
    static deserializeBinaryFromReader(message: VariationItem, reader: jspb.BinaryReader): VariationItem;
}

export namespace VariationItem {
    export type AsObject = {
        id: string,
        name: string,
        valuesList: Array<string>,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export enum VariationType {
    STRING = 0,
    NUMBER = 1,
    COLOR = 2,
    SIZE = 3,
}
