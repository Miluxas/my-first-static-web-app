// package: product
// file: category.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class CategoryAndParentId extends jspb.Message { 
    getId(): string;
    setId(value: string): CategoryAndParentId;

    getParentId(): string;
    setParentId(value: string): CategoryAndParentId;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): CategoryAndParentId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CategoryAndParentId.AsObject;
    static toObject(includeInstance: boolean, msg: CategoryAndParentId): CategoryAndParentId.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CategoryAndParentId, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CategoryAndParentId;
    static deserializeBinaryFromReader(message: CategoryAndParentId, reader: jspb.BinaryReader): CategoryAndParentId;
}

export namespace CategoryAndParentId {
    export type AsObject = {
        id: string,
        parentId: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class CategoryAttributes extends jspb.Message { 
    getId(): string;
    setId(value: string): CategoryAttributes;

    clearAttributesList(): void;
    getAttributesList(): Array<string>;
    setAttributesList(value: Array<string>): CategoryAttributes;
    addAttributes(value: string, index?: number): string;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): CategoryAttributes;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CategoryAttributes.AsObject;
    static toObject(includeInstance: boolean, msg: CategoryAttributes): CategoryAttributes.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CategoryAttributes, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CategoryAttributes;
    static deserializeBinaryFromReader(message: CategoryAttributes, reader: jspb.BinaryReader): CategoryAttributes;
}

export namespace CategoryAttributes {
    export type AsObject = {
        id: string,
        attributesList: Array<string>,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class Attributes extends jspb.Message { 
    clearAttributesList(): void;
    getAttributesList(): Array<string>;
    setAttributesList(value: Array<string>): Attributes;
    addAttributes(value: string, index?: number): string;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Attributes.AsObject;
    static toObject(includeInstance: boolean, msg: Attributes): Attributes.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: Attributes, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Attributes;
    static deserializeBinaryFromReader(message: Attributes, reader: jspb.BinaryReader): Attributes;
}

export namespace Attributes {
    export type AsObject = {
        attributesList: Array<string>,
    }
}

export class CategoryOrder extends jspb.Message { 
    getId(): string;
    setId(value: string): CategoryOrder;

    getOrder(): number;
    setOrder(value: number): CategoryOrder;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): CategoryOrder;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CategoryOrder.AsObject;
    static toObject(includeInstance: boolean, msg: CategoryOrder): CategoryOrder.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CategoryOrder, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CategoryOrder;
    static deserializeBinaryFromReader(message: CategoryOrder, reader: jspb.BinaryReader): CategoryOrder;
}

export namespace CategoryOrder {
    export type AsObject = {
        id: string,
        order: number,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
