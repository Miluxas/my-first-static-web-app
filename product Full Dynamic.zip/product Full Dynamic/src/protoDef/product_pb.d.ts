// package: product
// file: product.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class ProductAndCategoryId extends jspb.Message { 
    getId(): string;
    setId(value: string): ProductAndCategoryId;

    getCategoryId(): string;
    setCategoryId(value: string): ProductAndCategoryId;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): ProductAndCategoryId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ProductAndCategoryId.AsObject;
    static toObject(includeInstance: boolean, msg: ProductAndCategoryId): ProductAndCategoryId.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ProductAndCategoryId, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ProductAndCategoryId;
    static deserializeBinaryFromReader(message: ProductAndCategoryId, reader: jspb.BinaryReader): ProductAndCategoryId;
}

export namespace ProductAndCategoryId {
    export type AsObject = {
        id: string,
        categoryId: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class ProductAttributeItemIds extends jspb.Message { 
    getId(): string;
    setId(value: string): ProductAttributeItemIds;

    clearAttributeItemIdList(): void;
    getAttributeItemIdList(): Array<string>;
    setAttributeItemIdList(value: Array<string>): ProductAttributeItemIds;
    addAttributeItemId(value: string, index?: number): string;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): ProductAttributeItemIds;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ProductAttributeItemIds.AsObject;
    static toObject(includeInstance: boolean, msg: ProductAttributeItemIds): ProductAttributeItemIds.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ProductAttributeItemIds, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ProductAttributeItemIds;
    static deserializeBinaryFromReader(message: ProductAttributeItemIds, reader: jspb.BinaryReader): ProductAttributeItemIds;
}

export namespace ProductAttributeItemIds {
    export type AsObject = {
        id: string,
        attributeItemIdList: Array<string>,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class ProductSkuId extends jspb.Message { 
    getId(): string;
    setId(value: string): ProductSkuId;

    getSkuId(): string;
    setSkuId(value: string): ProductSkuId;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): ProductSkuId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ProductSkuId.AsObject;
    static toObject(includeInstance: boolean, msg: ProductSkuId): ProductSkuId.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: ProductSkuId, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ProductSkuId;
    static deserializeBinaryFromReader(message: ProductSkuId, reader: jspb.BinaryReader): ProductSkuId;
}

export namespace ProductSkuId {
    export type AsObject = {
        id: string,
        skuId: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class SkuGenerate extends jspb.Message { 
    getProductId(): string;
    setProductId(value: string): SkuGenerate;

    clearVariationsList(): void;
    getVariationsList(): Array<SGVariation>;
    setVariationsList(value: Array<SGVariation>): SkuGenerate;
    addVariations(value?: SGVariation, index?: number): SGVariation;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): SkuGenerate;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SkuGenerate.AsObject;
    static toObject(includeInstance: boolean, msg: SkuGenerate): SkuGenerate.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SkuGenerate, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SkuGenerate;
    static deserializeBinaryFromReader(message: SkuGenerate, reader: jspb.BinaryReader): SkuGenerate;
}

export namespace SkuGenerate {
    export type AsObject = {
        productId: string,
        variationsList: Array<SGVariation.AsObject>,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}

export class SGVariation extends jspb.Message { 
    getVariationId(): string;
    setVariationId(value: string): SGVariation;

    clearVariationItemIdList(): void;
    getVariationItemIdList(): Array<SGVariation.ItemId>;
    setVariationItemIdList(value: Array<SGVariation.ItemId>): SGVariation;
    addVariationItemId(value?: SGVariation.ItemId, index?: number): SGVariation.ItemId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SGVariation.AsObject;
    static toObject(includeInstance: boolean, msg: SGVariation): SGVariation.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: SGVariation, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SGVariation;
    static deserializeBinaryFromReader(message: SGVariation, reader: jspb.BinaryReader): SGVariation;
}

export namespace SGVariation {
    export type AsObject = {
        variationId: string,
        variationItemIdList: Array<SGVariation.ItemId.AsObject>,
    }


    export class ItemId extends jspb.Message { 
        getVariationItemId(): string;
        setVariationItemId(value: string): ItemId;

        getIsDefault(): boolean;
        setIsDefault(value: boolean): ItemId;


        serializeBinary(): Uint8Array;
        toObject(includeInstance?: boolean): ItemId.AsObject;
        static toObject(includeInstance: boolean, msg: ItemId): ItemId.AsObject;
        static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
        static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
        static serializeBinaryToWriter(message: ItemId, writer: jspb.BinaryWriter): void;
        static deserializeBinary(bytes: Uint8Array): ItemId;
        static deserializeBinaryFromReader(message: ItemId, reader: jspb.BinaryReader): ItemId;
    }

    export namespace ItemId {
        export type AsObject = {
            variationItemId: string,
            isDefault: boolean,
        }
    }

}

export class AppFilterList extends jspb.Message { 
    clearItemsList(): void;
    getItemsList(): Array<google_protobuf_struct_pb.Struct>;
    setItemsList(value: Array<google_protobuf_struct_pb.Struct>): AppFilterList;
    addItems(value?: google_protobuf_struct_pb.Struct, index?: number): google_protobuf_struct_pb.Struct;

    getHasnext(): boolean;
    setHasnext(value: boolean): AppFilterList;

    clearFilterOptionsList(): void;
    getFilterOptionsList(): Array<google_protobuf_struct_pb.Struct>;
    setFilterOptionsList(value: Array<google_protobuf_struct_pb.Struct>): AppFilterList;
    addFilterOptions(value?: google_protobuf_struct_pb.Struct, index?: number): google_protobuf_struct_pb.Struct;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): AppFilterList;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AppFilterList.AsObject;
    static toObject(includeInstance: boolean, msg: AppFilterList): AppFilterList.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: AppFilterList, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AppFilterList;
    static deserializeBinaryFromReader(message: AppFilterList, reader: jspb.BinaryReader): AppFilterList;
}

export namespace AppFilterList {
    export type AsObject = {
        itemsList: Array<google_protobuf_struct_pb.Struct.AsObject>,
        hasnext: boolean,
        filterOptionsList: Array<google_protobuf_struct_pb.Struct.AsObject>,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
