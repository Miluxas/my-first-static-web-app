// package: product
// file: page.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as page_pb from "./page_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

interface IPage_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    add: IPage_Service_Iadd;
    get: IPage_Service_Iget;
    getByName: IPage_Service_IgetByName;
    list: IPage_Service_Ilist;
    edit: IPage_Service_Iedit;
    delete: IPage_Service_Idelete;
    toggleActivation: IPage_Service_ItoggleActivation;
    setBoxOrder: IPage_Service_IsetBoxOrder;
    appGet: IPage_Service_IappGet;
    appList: IPage_Service_IappList;
    appGetByName: IPage_Service_IappGetByName;
}

interface IPage_Service_Iadd extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IPage_Service_Iget extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/get";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IPage_Service_IgetByName extends grpc.MethodDefinition<page_pb.ByName, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/getByName";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<page_pb.ByName>;
    requestDeserialize: grpc.deserialize<page_pb.ByName>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IPage_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Page_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}
interface IPage_Service_Iedit extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/edit";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IPage_Service_Idelete extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Page_/delete";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IPage_Service_ItoggleActivation extends grpc.MethodDefinition<common_pb.Activation, google_protobuf_empty_pb.Empty> {
    path: "/product.Page_/toggleActivation";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Activation>;
    requestDeserialize: grpc.deserialize<common_pb.Activation>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IPage_Service_IsetBoxOrder extends grpc.MethodDefinition<page_pb.BoxOrder, google_protobuf_empty_pb.Empty> {
    path: "/product.Page_/setBoxOrder";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<page_pb.BoxOrder>;
    requestDeserialize: grpc.deserialize<page_pb.BoxOrder>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface IPage_Service_IappGet extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/appGet";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface IPage_Service_IappList extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Page_/appList";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}
interface IPage_Service_IappGetByName extends grpc.MethodDefinition<page_pb.ByName, google_protobuf_struct_pb.Struct> {
    path: "/product.Page_/appGetByName";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<page_pb.ByName>;
    requestDeserialize: grpc.deserialize<page_pb.ByName>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}

export const Page_Service: IPage_Service;

export interface IPage_Server {
    add: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    get: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    getByName: grpc.handleUnaryCall<page_pb.ByName, google_protobuf_struct_pb.Struct>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
    edit: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    delete: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    toggleActivation: grpc.handleUnaryCall<common_pb.Activation, google_protobuf_empty_pb.Empty>;
    setBoxOrder: grpc.handleUnaryCall<page_pb.BoxOrder, google_protobuf_empty_pb.Empty>;
    appGet: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    appList: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
    appGetByName: grpc.handleUnaryCall<page_pb.ByName, google_protobuf_struct_pb.Struct>;
}

export interface IPage_Client {
    add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getByName(request: page_pb.ByName, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getByName(request: page_pb.ByName, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    getByName(request: page_pb.ByName, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setBoxOrder(request: page_pb.BoxOrder, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setBoxOrder(request: page_pb.BoxOrder, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    setBoxOrder(request: page_pb.BoxOrder, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appGetByName(request: page_pb.ByName, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGetByName(request: page_pb.ByName, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGetByName(request: page_pb.ByName, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
}

export class Page_Client extends grpc.Client implements IPage_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getByName(request: page_pb.ByName, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getByName(request: page_pb.ByName, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public getByName(request: page_pb.ByName, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setBoxOrder(request: page_pb.BoxOrder, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setBoxOrder(request: page_pb.BoxOrder, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public setBoxOrder(request: page_pb.BoxOrder, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appGetByName(request: page_pb.ByName, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGetByName(request: page_pb.ByName, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGetByName(request: page_pb.ByName, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
}
