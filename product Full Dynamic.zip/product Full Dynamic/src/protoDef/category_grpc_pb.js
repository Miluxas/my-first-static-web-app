// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var category_pb = require('./category_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var google_protobuf_struct_pb = require('google-protobuf/google/protobuf/struct_pb.js');
var common_pb = require('./common_pb.js');

function serialize_Activation(arg) {
  if (!(arg instanceof common_pb.Activation)) {
    throw new Error('Expected argument of type Activation');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Activation(buffer_arg) {
  return common_pb.Activation.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_AppList(arg) {
  if (!(arg instanceof common_pb.AppList)) {
    throw new Error('Expected argument of type AppList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_AppList(buffer_arg) {
  return common_pb.AppList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_BaseObject(arg) {
  if (!(arg instanceof common_pb.BaseObject)) {
    throw new Error('Expected argument of type BaseObject');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_BaseObject(buffer_arg) {
  return common_pb.BaseObject.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Filter(arg) {
  if (!(arg instanceof common_pb.Filter)) {
    throw new Error('Expected argument of type Filter');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Filter(buffer_arg) {
  return common_pb.Filter.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Id(arg) {
  if (!(arg instanceof common_pb.Id)) {
    throw new Error('Expected argument of type Id');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Id(buffer_arg) {
  return common_pb.Id.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Ids(arg) {
  if (!(arg instanceof common_pb.Ids)) {
    throw new Error('Expected argument of type Ids');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Ids(buffer_arg) {
  return common_pb.Ids.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_List(arg) {
  if (!(arg instanceof common_pb.List)) {
    throw new Error('Expected argument of type List');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_List(buffer_arg) {
  return common_pb.List.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Struct(arg) {
  if (!(arg instanceof google_protobuf_struct_pb.Struct)) {
    throw new Error('Expected argument of type google.protobuf.Struct');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Struct(buffer_arg) {
  return google_protobuf_struct_pb.Struct.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_Attributes(arg) {
  if (!(arg instanceof category_pb.Attributes)) {
    throw new Error('Expected argument of type product.Attributes');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_Attributes(buffer_arg) {
  return category_pb.Attributes.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_CategoryAndParentId(arg) {
  if (!(arg instanceof category_pb.CategoryAndParentId)) {
    throw new Error('Expected argument of type product.CategoryAndParentId');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_CategoryAndParentId(buffer_arg) {
  return category_pb.CategoryAndParentId.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_CategoryAttributes(arg) {
  if (!(arg instanceof category_pb.CategoryAttributes)) {
    throw new Error('Expected argument of type product.CategoryAttributes');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_CategoryAttributes(buffer_arg) {
  return category_pb.CategoryAttributes.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_CategoryOrder(arg) {
  if (!(arg instanceof category_pb.CategoryOrder)) {
    throw new Error('Expected argument of type product.CategoryOrder');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_CategoryOrder(buffer_arg) {
  return category_pb.CategoryOrder.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// Category Service
var Category_Service = exports.Category_Service = {
  add: {
    path: '/product.Category_/add',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  get: {
    path: '/product.Category_/get',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  getTree: {
    path: '/product.Category_/getTree',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  list: {
    path: '/product.Category_/list',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.List,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_List,
    responseDeserialize: deserialize_List,
  },
  edit: {
    path: '/product.Category_/edit',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.BaseObject,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_BaseObject,
    requestDeserialize: deserialize_BaseObject,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  delete: {
    path: '/product.Category_/delete',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  toggleActivation: {
    path: '/product.Category_/toggleActivation',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Activation,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Activation,
    requestDeserialize: deserialize_Activation,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  appGet: {
    path: '/product.Category_/appGet',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_struct_pb.Struct,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Struct,
    responseDeserialize: deserialize_google_protobuf_Struct,
  },
  appList: {
    path: '/product.Category_/appList',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.AppList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_AppList,
    responseDeserialize: deserialize_AppList,
  },
  setParent: {
    path: '/product.Category_/setParent',
    requestStream: false,
    responseStream: false,
    requestType: category_pb.CategoryAndParentId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_CategoryAndParentId,
    requestDeserialize: deserialize_product_CategoryAndParentId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  setOrder: {
    path: '/product.Category_/setOrder',
    requestStream: false,
    responseStream: false,
    requestType: category_pb.CategoryOrder,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_CategoryOrder,
    requestDeserialize: deserialize_product_CategoryOrder,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  deleteParent: {
    path: '/product.Category_/deleteParent',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Id,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_Id,
    requestDeserialize: deserialize_Id,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  addAttribute: {
    path: '/product.Category_/addAttribute',
    requestStream: false,
    responseStream: false,
    requestType: category_pb.CategoryAttributes,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_CategoryAttributes,
    requestDeserialize: deserialize_product_CategoryAttributes,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  deleteAttribute: {
    path: '/product.Category_/deleteAttribute',
    requestStream: false,
    responseStream: false,
    requestType: category_pb.CategoryAttributes,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_CategoryAttributes,
    requestDeserialize: deserialize_product_CategoryAttributes,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  getAttributes: {
    path: '/product.Category_/getAttributes',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Ids,
    responseType: category_pb.Attributes,
    requestSerialize: serialize_Ids,
    requestDeserialize: deserialize_Ids,
    responseSerialize: serialize_product_Attributes,
    responseDeserialize: deserialize_product_Attributes,
  },
};

exports.Category_Client = grpc.makeGenericClientConstructor(Category_Service);
