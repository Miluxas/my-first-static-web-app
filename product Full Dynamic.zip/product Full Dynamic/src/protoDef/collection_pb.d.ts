// package: product
// file: collection.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

export class CollectionId extends jspb.Message { 
    getId(): string;
    setId(value: string): CollectionId;


    hasFilter(): boolean;
    clearFilter(): void;
    getFilter(): google_protobuf_struct_pb.Struct | undefined;
    setFilter(value?: google_protobuf_struct_pb.Struct): CollectionId;

    getPage(): number;
    setPage(value: number): CollectionId;

    getLimit(): number;
    setLimit(value: number): CollectionId;

    getLogo(): string;
    setLogo(value: string): CollectionId;


    hasBaseinfo(): boolean;
    clearBaseinfo(): void;
    getBaseinfo(): common_pb.BaseInfo | undefined;
    setBaseinfo(value?: common_pb.BaseInfo): CollectionId;


    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CollectionId.AsObject;
    static toObject(includeInstance: boolean, msg: CollectionId): CollectionId.AsObject;
    static extensions: {[key: number]: jspb.ExtensionFieldInfo<jspb.Message>};
    static extensionsBinary: {[key: number]: jspb.ExtensionFieldBinaryInfo<jspb.Message>};
    static serializeBinaryToWriter(message: CollectionId, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CollectionId;
    static deserializeBinaryFromReader(message: CollectionId, reader: jspb.BinaryReader): CollectionId;
}

export namespace CollectionId {
    export type AsObject = {
        id: string,
        filter?: google_protobuf_struct_pb.Struct.AsObject,
        page: number,
        limit: number,
        logo: string,
        baseinfo?: common_pb.BaseInfo.AsObject,
    }
}
