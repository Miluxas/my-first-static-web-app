// package: product
// file: collection.proto

/* tslint:disable */
/* eslint-disable */

import * as grpc from "grpc";
import * as collection_pb from "./collection_pb";
import * as google_protobuf_empty_pb from "google-protobuf/google/protobuf/empty_pb";
import * as google_protobuf_struct_pb from "google-protobuf/google/protobuf/struct_pb";
import * as common_pb from "./common_pb";

interface ICollection_Service extends grpc.ServiceDefinition<grpc.UntypedServiceImplementation> {
    add: ICollection_Service_Iadd;
    get: ICollection_Service_Iget;
    list: ICollection_Service_Ilist;
    edit: ICollection_Service_Iedit;
    delete: ICollection_Service_Idelete;
    toggleActivation: ICollection_Service_ItoggleActivation;
    appGet: ICollection_Service_IappGet;
    appGetPagination: ICollection_Service_IappGetPagination;
    appList: ICollection_Service_IappList;
}

interface ICollection_Service_Iadd extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Collection_/add";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICollection_Service_Iget extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Collection_/get";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICollection_Service_Ilist extends grpc.MethodDefinition<common_pb.Filter, common_pb.List> {
    path: "/product.Collection_/list";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.List>;
    responseDeserialize: grpc.deserialize<common_pb.List>;
}
interface ICollection_Service_Iedit extends grpc.MethodDefinition<common_pb.BaseObject, google_protobuf_struct_pb.Struct> {
    path: "/product.Collection_/edit";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.BaseObject>;
    requestDeserialize: grpc.deserialize<common_pb.BaseObject>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICollection_Service_Idelete extends grpc.MethodDefinition<common_pb.Id, google_protobuf_empty_pb.Empty> {
    path: "/product.Collection_/delete";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICollection_Service_ItoggleActivation extends grpc.MethodDefinition<common_pb.Activation, google_protobuf_empty_pb.Empty> {
    path: "/product.Collection_/toggleActivation";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Activation>;
    requestDeserialize: grpc.deserialize<common_pb.Activation>;
    responseSerialize: grpc.serialize<google_protobuf_empty_pb.Empty>;
    responseDeserialize: grpc.deserialize<google_protobuf_empty_pb.Empty>;
}
interface ICollection_Service_IappGet extends grpc.MethodDefinition<common_pb.Id, google_protobuf_struct_pb.Struct> {
    path: "/product.Collection_/appGet";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Id>;
    requestDeserialize: grpc.deserialize<common_pb.Id>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICollection_Service_IappGetPagination extends grpc.MethodDefinition<collection_pb.CollectionId, google_protobuf_struct_pb.Struct> {
    path: "/product.Collection_/appGetPagination";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<collection_pb.CollectionId>;
    requestDeserialize: grpc.deserialize<collection_pb.CollectionId>;
    responseSerialize: grpc.serialize<google_protobuf_struct_pb.Struct>;
    responseDeserialize: grpc.deserialize<google_protobuf_struct_pb.Struct>;
}
interface ICollection_Service_IappList extends grpc.MethodDefinition<common_pb.Filter, common_pb.AppList> {
    path: "/product.Collection_/appList";
    requestStream: false;
    responseStream: false;
    requestSerialize: grpc.serialize<common_pb.Filter>;
    requestDeserialize: grpc.deserialize<common_pb.Filter>;
    responseSerialize: grpc.serialize<common_pb.AppList>;
    responseDeserialize: grpc.deserialize<common_pb.AppList>;
}

export const Collection_Service: ICollection_Service;

export interface ICollection_Server {
    add: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    get: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    list: grpc.handleUnaryCall<common_pb.Filter, common_pb.List>;
    edit: grpc.handleUnaryCall<common_pb.BaseObject, google_protobuf_struct_pb.Struct>;
    delete: grpc.handleUnaryCall<common_pb.Id, google_protobuf_empty_pb.Empty>;
    toggleActivation: grpc.handleUnaryCall<common_pb.Activation, google_protobuf_empty_pb.Empty>;
    appGet: grpc.handleUnaryCall<common_pb.Id, google_protobuf_struct_pb.Struct>;
    appGetPagination: grpc.handleUnaryCall<collection_pb.CollectionId, google_protobuf_struct_pb.Struct>;
    appList: grpc.handleUnaryCall<common_pb.Filter, common_pb.AppList>;
}

export interface ICollection_Client {
    add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGetPagination(request: collection_pb.CollectionId, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGetPagination(request: collection_pb.CollectionId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appGetPagination(request: collection_pb.CollectionId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
}

export class Collection_Client extends grpc.Client implements ICollection_Client {
    constructor(address: string, credentials: grpc.ChannelCredentials, options?: object);
    public add(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public add(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public get(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public list(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.List) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public edit(request: common_pb.BaseObject, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public delete(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public toggleActivation(request: common_pb.Activation, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_empty_pb.Empty) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGet(request: common_pb.Id, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGetPagination(request: collection_pb.CollectionId, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGetPagination(request: collection_pb.CollectionId, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appGetPagination(request: collection_pb.CollectionId, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: google_protobuf_struct_pb.Struct) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
    public appList(request: common_pb.Filter, metadata: grpc.Metadata, options: Partial<grpc.CallOptions>, callback: (error: grpc.ServiceError | null, response: common_pb.AppList) => void): grpc.ClientUnaryCall;
}
