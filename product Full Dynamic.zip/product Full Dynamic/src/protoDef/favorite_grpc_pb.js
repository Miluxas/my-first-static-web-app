// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var favorite_pb = require('./favorite_pb.js');
var google_protobuf_empty_pb = require('google-protobuf/google/protobuf/empty_pb.js');
var common_pb = require('./common_pb.js');

function serialize_AppList(arg) {
  if (!(arg instanceof common_pb.AppList)) {
    throw new Error('Expected argument of type AppList');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_AppList(buffer_arg) {
  return common_pb.AppList.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_Filter(arg) {
  if (!(arg instanceof common_pb.Filter)) {
    throw new Error('Expected argument of type Filter');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_Filter(buffer_arg) {
  return common_pb.Filter.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_google_protobuf_Empty(arg) {
  if (!(arg instanceof google_protobuf_empty_pb.Empty)) {
    throw new Error('Expected argument of type google.protobuf.Empty');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_google_protobuf_Empty(buffer_arg) {
  return google_protobuf_empty_pb.Empty.deserializeBinary(new Uint8Array(buffer_arg));
}

function serialize_product_OwnerId(arg) {
  if (!(arg instanceof favorite_pb.OwnerId)) {
    throw new Error('Expected argument of type product.OwnerId');
  }
  return Buffer.from(arg.serializeBinary());
}

function deserialize_product_OwnerId(buffer_arg) {
  return favorite_pb.OwnerId.deserializeBinary(new Uint8Array(buffer_arg));
}


// *
// Favorite Service
var Favorite_Service = exports.Favorite_Service = {
  remove: {
    path: '/product.Favorite_/remove',
    requestStream: false,
    responseStream: false,
    requestType: favorite_pb.OwnerId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_OwnerId,
    requestDeserialize: deserialize_product_OwnerId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  add: {
    path: '/product.Favorite_/add',
    requestStream: false,
    responseStream: false,
    requestType: favorite_pb.OwnerId,
    responseType: google_protobuf_empty_pb.Empty,
    requestSerialize: serialize_product_OwnerId,
    requestDeserialize: deserialize_product_OwnerId,
    responseSerialize: serialize_google_protobuf_Empty,
    responseDeserialize: deserialize_google_protobuf_Empty,
  },
  list: {
    path: '/product.Favorite_/list',
    requestStream: false,
    responseStream: false,
    requestType: common_pb.Filter,
    responseType: common_pb.AppList,
    requestSerialize: serialize_Filter,
    requestDeserialize: deserialize_Filter,
    responseSerialize: serialize_AppList,
    responseDeserialize: deserialize_AppList,
  },
};

exports.Favorite_Client = grpc.makeGenericClientConstructor(Favorite_Service);
