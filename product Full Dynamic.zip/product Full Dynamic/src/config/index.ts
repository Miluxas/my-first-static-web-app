import { config } from 'dotenv';
import path from 'path';

const envFound = config({ path: path.join(process.cwd(), '.env') });
if (envFound.error) {
    // This error should crash whole process
    throw new Error("⚠️  Couldn't find .env file  ⚠️");
}

export default {
    /**
     * Your favorite port
     */
    port: Number(process.env.PORT) || 7000,
    /**
     * API configs
     */
    api: {
        prefix: '/api',
    },
    mongoDB: {
        host: process.env.MONGO_INITDB_HOST,
        port: process.env.MONGO_INITDB_PORT,
        dbName: process.env.MONGO_INITDB_DATABASE,
        user: process.env.MONGO_INITDB_ROOT_USERNAME,
        pass: process.env.MONGO_INITDB_ROOT_PASSWORD,
    },

    /**
     * redis config
     */
    redis: {
        host: process.env.REDIS_HOST, //process.env.REDIS_HOST_DEV
        port: process.env.REDIS_PORT,
        username: process.env.REDIS_USERNAME,
        password: process.env.REDIS_PASSWORD,
        expire: 60000 * 60,
    },

    media_url: 'https://ec.nizek.com/media/',

    mail: {
        host: 'smtp.gmail.com',
        port: 587,
        username: 'automated@nizek.com',
        password: '@nizek123456_',
        from: 'kidsapp@nizek.com',
        from_name: 'Crowded App',
    },

    MS: {
        user: {
            ip: process.env.USER_SERVICE,
            port: process.env.USER_SERVICE_PORT,
        },
        product: {
            ip: process.env.PRODUCT_SERVICE,
            port: process.env.PRODUCT_SERVICE_PORT,
        },
        inventory: {
            ip: process.env.INVENTORY_SERVICE,
            port: process.env.INVENTORY_SERVICE_PORT,
        },
        order: {
            ip: process.env.ORDER_SERVICE,
            port: process.env.ORDER_SERVICE_PORT,
        },
    },
};
