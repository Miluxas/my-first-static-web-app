import { Server, ServerCredentials } from 'grpc';
import { Brand_Service } from './protoDef/brand_grpc_pb';
import CollectionCron from './collections/collection/cronJob';
import BrandServer from './collections/brand/rpc';
import { Category_Service } from './protoDef/category_grpc_pb';
import CategoryServer from './collections/category/rpc';
import { Product_Service } from './protoDef/product_grpc_pb';
import ProductServer from './collections/product/rpc';
import { Variation_Service } from './protoDef/variation_grpc_pb';
import VariationServer from './collections/variation/rpc';
import { Sku_Service as SkuS } from './protoDef/sku_grpc_pb';
import SkuServer from './collections/sku/rpc';
import { Collection_Service as CollectionS } from './protoDef/collection_grpc_pb';
import CollectionServer from './collections/collection/rpc';
import { Favorite_Service as FavoriteS } from './protoDef/favorite_grpc_pb';
import FavoriteServer from './collections/favorite/rpc';
import { Box_Service as BoxS } from './protoDef/box_grpc_pb';
import BoxServer from './collections/box/rpc';
import { Page_Service as PageS } from './protoDef/page_grpc_pb';
import PageServer from './collections/page/rpc';
import { Badge_Service as BadgeS } from './protoDef/badge_grpc_pb';
import BadgeServer from './collections/badge/rpc';
import { Attribute_Service as AttributeS } from './protoDef/attribute_grpc_pb';
import AttributeServer from './collections/attribute/rpc';
import { FilterMapping_Service as FilterMappingS } from './protoDef/filter_mapping_grpc_pb';
import FilterMappingServer from './collections/filterMapping/rpc';
import { FilterMappingItem_Service as FilterMappingItemS } from './protoDef/filter_mapping_item_grpc_pb';
import FilterMappingItemServer from './collections/filterMappingItem/rpc';
import SizeGuideServer from './collections/sizeGuide/rpc';
import { SizeGuide_Service as SizeGuideS } from './protoDef/sizeGuide_grpc_pb';
import TagServer from './collections/tag/rpc';
import { Tag_Service as TagS } from './protoDef/tag_grpc_pb';
import config from './config';
import { connectMongoose } from './config/db';

const port = config.port;

const server: Server = new Server({
    'grpc.max_receive_message_length': -1,
    'grpc.max_send_message_length': -1,
    // 'grpc.enable_http_proxy': 0,
});

/*
 * db Mongoose connection
 * */
connectMongoose.connection();

/** Add a new Brand Server to main gRPC server */
server.addService(Brand_Service, new BrandServer());

/** Add a new Category Server to main gRPC server */
server.addService(Category_Service, new CategoryServer());

/** Add a new Product Server to main gRPC server */
server.addService(Product_Service, new ProductServer());

/** Add a new Attribute Server to main gRPC server */
server.addService(Variation_Service, new VariationServer());

/** Add a new Sku Server to main gRPC server */
server.addService(SkuS, new SkuServer());

/** Add a new Collection Server to main gRPC server */
server.addService(CollectionS, new CollectionServer());

/** Add a new Favorite Server to main gRPC server */
server.addService(FavoriteS, new FavoriteServer());

/** Add a new Box Server to main gRPC server */
server.addService(BoxS, new BoxServer());

/** Add a new Page Server to main gRPC server */
server.addService(PageS, new PageServer());

/** Add a new Badge Server to main gRPC server */
server.addService(BadgeS, new BadgeServer());

/** Add a new Attribute Server to main gRPC server */
server.addService(AttributeS, new AttributeServer());

/** Add a new FilterMapping Server to main gRPC server */
server.addService(FilterMappingS, new FilterMappingServer());

/** Add a new FilterMappingItem Server to main gRPC server */
server.addService(FilterMappingItemS, new FilterMappingItemServer());

/** Add a new Tag Server to main gRPC server */
server.addService(TagS, new TagServer());

/** Add a new SizeGude Server to main gRPC server */
server.addService(SizeGuideS, new SizeGuideServer());

server.bind(`0.0.0.0:${port}`, ServerCredentials.createInsecure());
server.start();

console.log(`Product Server is listening on port ${port}!`);
console.log(`
███╗   ██╗███████╗        ███╗   ███╗ ██████╗ ██████╗ ██╗███████╗██╗  ██╗
████╗  ██║╚══███╔╝        ████╗ ████║██╔═══██╗██╔══██╗██║██╔════╝██║  ██║
██╔██╗ ██║  ███╔╝         ██╔████╔██║██║   ██║██║  ██║██║███████╗███████║
██║╚██╗██║ ███╔╝          ██║╚██╔╝██║██║   ██║██║  ██║██║╚════██║██╔══██║
██║ ╚████║███████╗███████╗██║ ╚═╝ ██║╚██████╔╝██████╔╝██║███████║██║  ██║
╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚═╝╚══════╝╚═╝  ╚═╝
                                                                         
    ██████╗ ██████╗  ██████╗ ██████╗ ██╗   ██╗ ██████╗████████╗          
    ██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██║   ██║██╔════╝╚══██╔══╝          
    ██████╔╝██████╔╝██║   ██║██║  ██║██║   ██║██║        ██║             
    ██╔═══╝ ██╔══██╗██║   ██║██║  ██║██║   ██║██║        ██║             
    ██║     ██║  ██║╚██████╔╝██████╔╝╚██████╔╝╚██████╗   ██║             
    ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝  ╚═════╝   ╚═╝             
                                                                         `);

const collectionCron: CollectionCron = new CollectionCron();

collectionCron.setup();
console.log(`Setup CronJobs !`);

// server Crash Handle
process.on('unhandledRejection', (reason, promise) => {
    console.error('!!!!! SERVER unhandledRejection at:', reason || promise);
    // Recommended: send the information to sentry.io
    // or whatever crash reporting service you use
});
process.on('uncaughtException', function (err) {
    console.error('!!!!! SERVER uncaughtException err:', err);
});
